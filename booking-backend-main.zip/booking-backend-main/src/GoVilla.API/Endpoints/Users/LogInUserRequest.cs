namespace GoVilla.API.Endpoints.Users;

public sealed record LogInUserRequest(string Email, string Password);