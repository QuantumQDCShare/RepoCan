namespace GoVilla.Application.Users.LogInUser;

public sealed record AccessTokenResponse(string AccessToken);