namespace GoVilla.Application.Abstractions.Authentication;

public interface IUserContext
{
    string IdentityId { get; }
}