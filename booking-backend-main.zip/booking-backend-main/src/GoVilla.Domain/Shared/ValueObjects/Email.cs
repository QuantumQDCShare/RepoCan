namespace GoVilla.Domain.Shared.ValueObjects;

public record Email(string Value);