namespace GoVilla.Domain.Apartments.ValueObjects;

public record Name(string Value);