namespace GoVilla.Domain.Apartments.ValueObjects;

public record Description(string Value);