namespace GoVilla.Domain.Users.ValueObjects;

public record LastName(string Value);