namespace GoVilla.Domain.Reviews.ValueObjects;

public record Comment(string Value);