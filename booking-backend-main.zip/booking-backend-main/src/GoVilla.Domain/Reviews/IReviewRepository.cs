namespace GoVilla.Domain.Reviews;

public interface IReviewRepository
{
    void Add(Review review);
}