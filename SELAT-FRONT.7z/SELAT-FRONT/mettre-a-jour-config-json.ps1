$courant = Get-Location
Set-Location dist/rat-hli5_v2cnsulrapp_an/assets
$nomFichier = Get-ChildItem main*.js | Select-Object -Expand basename
$configJson = @{}
$configJson.Add("ENVIRONNEMENT", "unit")
$configJson.Add("VERSION", "0.0.0")
$configJson.Add("OIDC_AUTORITE", "https://fedapp.intro.ramq.gouv.qc.ca/adfs")
$configJson.Add("OIDC_CLIENT_ID", "http://rat-hli5_v2cnsulrapp_an-unit")
$configJson.Add("OIDC_HOTE_REDIRECTION", "http://localhost:4200")
$configJson.Add("OIDC_SCOPE_API", "http://rat-hli5_v2cnsulrapp_an-api-unit/openid profile carnet:lire pilotage:lire pilotage:ecrire")
$configJson.Add("CHEMIN_API", "https://localhost:5011/api/1/")

New-Item -Path "." -Name "config" -ItemType "directory"
Set-Location config
$configJson | ConvertTo-Json -Depth 10 | Out-File  "config.json"
Set-Location $courant
