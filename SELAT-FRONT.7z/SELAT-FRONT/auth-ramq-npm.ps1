npm list -g vsts-npm-auth -or npm install -g vsts-npm-auth;
vsts-npm-auth -config .npmrc;
Copy-Item ./prod.npmrc -Destination .npmrc
Get-Content Z:/.npmrc | Add-Content .npmrc