export const environment = {
  production: true,
  apiEndpoint: 'http://localhost:3001'
};
