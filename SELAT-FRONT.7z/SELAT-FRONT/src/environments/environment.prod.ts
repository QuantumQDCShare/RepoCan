import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { AuthentificationOidcInterceptorService } from 'src/app/securite/authentification';

export const environment = {
  production: true,
  configuration: '/assets/config/config.json', // Placeholder

  interceptors: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthentificationOidcInterceptorService, multi: true }
  ]
};
