import { HTTP_INTERCEPTORS } from '@angular/common/http';

import { AuthentificationOidcInterceptorService } from 'src/app/securite/authentification';

export const environment = {
  production: false,
  configuration: '/assets/config/config.json',

  interceptors: [
    // { provide: HTTP_INTERCEPTORS, useClass: SimulationInterceptorService, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: AuthentificationOidcInterceptorService, multi: true }
  ]
};
