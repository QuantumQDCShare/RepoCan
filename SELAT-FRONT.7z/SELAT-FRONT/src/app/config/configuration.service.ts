import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

export interface Configuration {
  apiUrl: string;
  stage: string;
}

@Injectable({providedIn: 'root'})
export class ConfigurationService {

  private readonly CONFIG_URL = 'assets/config/config.json';
  private configs: Configuration;

  constructor(private readonly http: HttpClient) {
  }

  get apiUrl() {
    return this.configs ? this.configs.apiUrl : undefined;
  }


  public async loadConfigs(): Promise<any> {
    return this.http.get(this.CONFIG_URL).pipe(settings => settings)
      .toPromise()
      .then(settings => {
        this.configs = settings as Configuration;
      });
  }
}
