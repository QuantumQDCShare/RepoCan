import { CommonModule } from '@angular/common';
import { Component, HostListener, Inject, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { GenererAvisComponent } from 'src/app/hlh1-consulter-avis/generer-avis/generer-avis.component';
import { ServCnsulAvisInterface } from 'src/app/serv-cnsul-avis-interface';
import { StubServCnsulAvisService } from 'src/app/services/hlh1-consulter-avis-services/stub-serv-cnsul-avis.service';

@Component({
  selector: 'hla5-contexte-travail',
  standalone: true,
  imports: [CommonModule, FormsModule, GenererAvisComponent],
  providers: [{ provide: 'ServCnsulAvisInterface', useClass: StubServCnsulAvisService }],
  templateUrl: './hla5-contexte-travail.component.html',
  styleUrl: './hla5-contexte-travail.component.scss'
})
export class Hla5ContexteTravailComponent implements OnInit {
  constructor(@Inject('ServCnsulAvisInterface') private service: ServCnsulAvisInterface) { }

  
  progmVoletSelect: string = '';
  Message: string = '';
  ListeProgmVolet: any[] = [];
  colctMsgRetou: string[] = [];
  blnMsgTraitSeverHaut: boolean = true;
  DivMsgestVisible: boolean = false;
  Chargement: boolean = false;
  OptionSelect: string = 'Selectionner une option';
  estOuvert: boolean = false;
  surbrillanceOption: string | null = null;

  activerSelect(event: MouseEvent) {
    this.estOuvert = !this.estOuvert;
    event.stopPropagation();
  }

  @HostListener('document:click', ['$event'])
  fermetureSelect(event: Event) {
    if (this.estOuvert) {
      this.estOuvert = false;
    }
  }

  progmSelect(nomProgrVolet: string, codeProgrVolet: string) {
    this.OptionSelect = nomProgrVolet;
    this.estOuvert = false;
    this.AvoirMessageErr(codeProgrVolet);
  }

  SurbrillanceOptions(option: string) {
    this.surbrillanceOption = option;
  }


  ngOnInit(): void {
    this.service.ObtenirProgrammeVolet().subscribe({
      next: (data: any) => {
        this.ListeProgmVolet = data.programmesVollets;
      },
      error: (err: any) => {
        console.error('Erreur lors du chargement du fichier JSON :', err);
      },
    });
  }

  AvoirMessageErr(progmVoletSelect: string): boolean {
    this.Chargement = true;
    setTimeout(() => { //enlever ce setTimeout lorsque les données arrivront du Back-end
      console.log('Délai de 3 secondes écoulé');
      this.service.VerifierTypeAvis(progmVoletSelect).subscribe({
        next: data => {
          this.colctMsgRetou = data;
          if (this.colctMsgRetou.length > 0) {
            // this.blnMsgTraitSeverHaut = true;
            this.DivMsgestVisible = true;
            this.AfficherMessageErreur(this.colctMsgRetou[0]);
          } else {
            // this.blnMsgTraitSeverHaut = false;
          }
        },
        error: err => {
          console.error('Erreur lors du parsing JSON :', err);
        }
      });
      this.Chargement = false;
    }, 2000);

    // return this.blnMsgTraitSeverHaut;
    return false;
  }

  AfficherMessageErreur(Message: string) {
    this.Message = Message;
  }
}
