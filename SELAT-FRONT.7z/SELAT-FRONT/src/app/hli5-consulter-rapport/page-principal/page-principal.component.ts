import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { rapport } from '../../models/rapport.model';
import { repertoire } from '../../models/repert.model';
import { AffichageRepertoireComponent } from '../affichage-repertoire/affichage-repertoire.component';
import { User } from 'oidc-client-ts';
import { RapportService } from 'src/app/services/rapport.service';

@Component({
  selector: 'app-principal',
  standalone: true,
  imports: [CommonModule, AffichageRepertoireComponent],
  templateUrl: './page-principal.component.html',
  styleUrl: './page-principal.component.scss'
})
export class PagePrincipalComponent implements OnInit {
  listeRepertoires: repertoire[] = [];
  repertoiresParent: repertoire[] = [];
  listeRapp: rapport[] = [];
  initialisationFini: boolean = false;
  uilisateurCourant: User;

  constructor(private service: RapportService) { }

  ngOnInit(): void {
    this.service.ObtenirListeRepert().subscribe({
      next: data => {
        this.listeRepertoires = data;
        this.repertoiresParent = this.listeRepertoires.filter(dossierParent => dossierParent.NomRpt.substring(0, 3) == 'HLI');
        this.initialisationFini = true;
      },
      error: err => {
        throw new Error('Une erreur est survenu : ', err);
      }
    });
  }

  gestionAffichage($event: Event) {
    const myEvent = ($event.target as HTMLInputElement);
    if (myEvent.tagName == 'LI') {
      for (let i = 0; i < myEvent.childElementCount; i++) {
        const childElement = myEvent.children[i] as HTMLElement;
        if (childElement.tagName !== 'IMG')
          childElement.hidden = !childElement.hidden;
      }
    }
    if (($event.target as HTMLInputElement).className == 'fleche-droite') {
      ($event.target as HTMLInputElement).className = 'fleche-bas';
    } else if (($event.target as HTMLInputElement).className == 'fleche-bas') {
      ($event.target as HTMLInputElement).className = 'fleche-droite';
    }
  }
}