import { CommonModule } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { repertoire } from '../../models/repert.model';
import { rapport } from '../../models/rapport.model';
import { RapportService } from 'src/app/services/rapport.service';

@Component({
  selector: 'app-affichage-repertoire',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './affichage-repertoire.component.html',
  styleUrl: './affichage-repertoire.component.scss'
})
export class AffichageRepertoireComponent implements OnInit {
  @Input() repertoiresParent: repertoire[] = [];
  @Input() listeRepertoires: repertoire[] = [];

  private rapportCache: { [key: number]: rapport[] } = {};

  constructor(private service: RapportService) { }

  ngOnInit(): void {
    for (const repert of this.repertoiresParent) {
      this.ajouterRapport(repert);
    }
  }

  ajouterRapport(repert: repertoire) {
    const rapp: rapport = {
      IdRapp: repert.IdRpt,
      NomRapp: repert.NomRapp,
      FormeRapp: repert.FormeRapp,
      CheminRapp: repert.CheminRpt
    };

    this.service.ObtenirListeRapp(rapp).subscribe({
      next: listeRapport => {
        const rapports = listeRapport;
        this.rapportCache[repert.IdRpt] = rapports;
      },
      error: err => {
        throw new Error('Erreur lors de la récupération des données :', err);
      }
    });
  }

  estParent(parentId: number): boolean {
    return this.listeRepertoires.some(rep => rep.ParenRpt === parentId);
  }

  avoirRepertoireEnfant(parentId: number): repertoire[] {
    return this.listeRepertoires.filter(rep => rep.ParenRpt === parentId);
  }

  avoirRapport(repert: repertoire): rapport[] {
    return this.rapportCache[repert.IdRpt];
  }
}
