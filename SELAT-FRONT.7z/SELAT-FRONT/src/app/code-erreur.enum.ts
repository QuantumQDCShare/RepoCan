export enum CodeErreur {
  HLI5_1001 = 'ERREURS.HLI5-1001'
}
