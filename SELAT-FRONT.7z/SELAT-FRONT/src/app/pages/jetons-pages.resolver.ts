import { InjectionToken } from '@angular/core';
import { AppStates } from '../app.states.enum';

import { ReponseResolver } from 'src/app/models/reponse-resolver.model';
import { Accueil } from '@modeles/accueil.model';

export const PAGE_ACCUEIL = new InjectionToken<ReponseResolver<Accueil>>(AppStates.PagePrincipal);