import { MockBuilder, MockRender, MockedComponentFixture, ngMocks } from 'ng-mocks';

import { ErreurTechniqueComponent } from './erreur-technique.component';

describe('ErreurTechniqueComponent', () => {
  beforeAll(() => ngMocks.autoSpy('jasmine'));
  afterAll(() => ngMocks.autoSpy('reset'));

  let fixture: MockedComponentFixture<ErreurTechniqueComponent>;
  let component: ErreurTechniqueComponent;

  beforeEach(() => MockBuilder(ErreurTechniqueComponent)
    .finally(() => {
      fixture = MockRender(ErreurTechniqueComponent);
      component = fixture.point.componentInstance;
    })
  );

  describe(`Initialisation`, () => {
    it(`doit être créé`, () => {
      expect(component).toBeTruthy();
    });
  });
});


