import { Component } from '@angular/core';

@Component({
  selector: 'hli5-erreur-technique',
  template: `
    <div>
      <h1>Erreur Technique</h1>
      <h3><a href="/">revenir au menu principal</a></h3>
    </div>
  `
})
export class ErreurTechniqueComponent { }
