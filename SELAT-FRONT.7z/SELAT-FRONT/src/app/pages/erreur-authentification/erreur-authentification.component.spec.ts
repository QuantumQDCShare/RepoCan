/*import { inject } from '@angular/core/testing';
import { MockBuilder, MockRender, MockService, MockedComponentFixture, ngMocks } from 'ng-mocks';
import { ErreurAuthentificationComponent } from './erreur-authentification.component';
import { Transition } from '@uirouter/angular';
import { TranslateService } from '@ngx-translate/core';
import { AuthentificationFacadeService, StatutAuthentification } from '@authentification';
import { Spy, createSpyFromClass } from 'jasmine-auto-spies';
import { v4 as UUID } from 'uuid';

describe('ErreurAuthentificationComponent', () => {
  beforeAll(() => ngMocks.autoSpy('jasmine'));
  afterAll(() => ngMocks.autoSpy('reset'));

  let fixture: MockedComponentFixture<ErreurAuthentificationComponent>;
  let component: ErreurAuthentificationComponent;
  let mockAuthentificationFacadeService: Spy<AuthentificationFacadeService>;
  let mockTransition: Spy<Transition>;

  beforeEach(() => {
    mockAuthentificationFacadeService = createSpyFromClass(AuthentificationFacadeService, { gettersToSpyOn: ['Etat'] });
    mockTransition = MockService(Transition, { params: jasmine.createSpy().and.returnValue({}) }) as never;

    return MockBuilder(ErreurAuthentificationComponent)
      .mock(AuthentificationFacadeService, mockAuthentificationFacadeService)
      .mock(TranslateService, { instant: jasmine.createSpy().and.callFake(param => param) })
      .mock(Transition, mockTransition)
      .finally(() => {
        fixture = MockRender(ErreurAuthentificationComponent);
        component = fixture.point.componentInstance;
      });
  });

  describe(`Initialisation`, () => {
    const reinitialiserComposant = (statut?: StatutAuthentification) => {
      if (statut) {
        mockAuthentificationFacadeService.accessorSpies.getters.Etat.and.returnValue(statut);
      }

      fixture = MockRender(ErreurAuthentificationComponent, undefined, { reset: true });
      component = fixture.point.componentInstance;
    };

    it(`doit être créé`, () => {
      expect(component).toBeTruthy();
    });

    it(`doit récupérer l'état d'authentification du service d'authentification`, () => {
      expect(mockAuthentificationFacadeService.accessorSpies.getters.Etat).toHaveBeenCalled();
    });

    describe(`la propriété 'erreur'`, () => {
      let translate: Spy<TranslateService>;

      beforeEach(inject([TranslateService], (service: Spy<TranslateService>) => translate = service));

      it(`doit être la traduction de la chaîne 'Authentification' SI le paramètre de transition de routage 'code' est absent ET que l'utilisateur n'est pas authentifié`, () => {
        expect('Authentification').toEqual(component.erreur);
        expect(translate.instant).toHaveBeenCalledOnceWith('Authentification', undefined);
      });

      it(`doit être la traduction de la chaîne 'Autorisation' SI le paramètre de transition de routage 'code' est absent ET que l'utilisateur est authentifié`, () => {
        translate.instant.calls.reset();
        reinitialiserComposant(StatutAuthentification.Authentifie);

        expect('Autorisation').toEqual(component.erreur);
        expect(translate.instant).toHaveBeenCalledOnceWith('Autorisation', undefined);
      });

      it(`doit être la traduction du code du paramètre transisiton de routage SI ce derniser est présent`, () => {
        const codeAttendu = UUID();
        mockTransition.params.and.returnValue({ code: codeAttendu });

        translate.instant.calls.reset();
        reinitialiserComposant();

        expect(codeAttendu).toEqual(component.erreur);
        expect(translate.instant).toHaveBeenCalledOnceWith(codeAttendu, undefined);
      });

      it(`doit être la traduction complète du code du paramètre transisiton de routage SI ce derniser est présent ET qu'un paramètre supplémentaire est fourni`, () => {
        const codeAttendu = UUID();
        const paramsAttendu = UUID();
        mockTransition.params.and.returnValue({ code: codeAttendu, params: paramsAttendu });

        translate.instant.calls.reset();
        reinitialiserComposant();

        expect(codeAttendu).toEqual(component.erreur);
        expect(translate.instant).toHaveBeenCalledOnceWith(codeAttendu, paramsAttendu);
      });
    });
  });
});
*/