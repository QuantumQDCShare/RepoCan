import { Component } from '@angular/core';

@Component({
  selector: 'hli5-erreur-authentification',
  template: `<p>Erreur - {{ erreur }}
  <a href="#">Retourner vers le menu principal</a></p>`
})
export class ErreurAuthentificationComponent {
  readonly erreur: string;

  constructor() {
    this.erreur = 'Erreur lors de l\'authentification';
  }
}
