import { Component } from '@angular/core';

@Component({
  selector: 'app-introuvable',
  standalone: true,
  imports: [],
  templateUrl: './introuvable.component.html'
})
export class IntrouvableComponent { }
