import { AbstractControl } from '@angular/forms';
import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class FieldErrorsService {
  ShowError(control: AbstractControl, forceShowError: boolean): boolean {
    return control.invalid && (control.dirty || control.touched || forceShowError) ;
  }

  GetErrorClasses(control: AbstractControl, forceShowError: boolean) {
    return {
      invalid: this.ShowError(control, forceShowError)
    };
  }
}
