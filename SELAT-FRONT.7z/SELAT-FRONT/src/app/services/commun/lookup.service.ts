import { Injectable } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Observable, map, tap } from 'rxjs';
import { EntiteLookUp } from 'src/app/models/commun/entity.model';

@Injectable({
  providedIn: 'root'
})
export class LookupService <T extends EntiteLookUp> {
  protected dataStore: {lookups: T[] } = { lookups: []};
  protected lookupApiUrl: string;

  constructor( readonly http: HttpClient) { }

  
  public loadAll() {
    this.lookups$.subscribe
    (success => {}, error => console.log('Could not load lookups'));
  }
  
  public loadAllPromise(): Promise<T[] > {
    return this.lookups$.toPromise();
  }

  get lookups$(): Observable<T[]> {
    return this.http.get<T[]>(this.lookupApiUrl)
      .pipe(tap(data => {
        data.sort((a, b) => {
          return this.defaultSort(a, b);
        });
      }))
      .pipe(map(data => {
        this.dataStore.lookups = data;
        return data;
      }));
  }

  get(id: number): T  {
    return this.dataStore.lookups.find(p => p.id === id);
  }

  getByCode(code: string): T {
    if (this.dataStore.lookups.length === 0) {
      this.loadAllPromise();
    }
    return this.dataStore.lookups.find(p => p.code === code);
  }
  
  defaultSort(a: T, b: T): number {
    return a.nom.localeCompare(b.nom);
  }
}
