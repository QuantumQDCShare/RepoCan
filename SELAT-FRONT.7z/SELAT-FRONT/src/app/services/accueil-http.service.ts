import { Inject, Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { CONTEXTESERVICE, ContexteService } from 'src/app/securite/contexte';
import { JournalisationService, Niveau } from 'src/app/journalisation.service';
import { Accueil } from '@modeles/accueil.model';

@Injectable({
  providedIn: 'root'
})
export class AccueilHttpService {

  constructor(
    private journal: JournalisationService,
    @Inject(CONTEXTESERVICE) private contexte: ContexteService
  ) { }

  accueil(): Observable<Accueil | null> {
    try {
      const donneesAccueil: Accueil = {
        uid: this.contexte.IdUtil
      };
      console.log('donneesAccueil :', donneesAccueil);
      console.log('UUID :', this.contexte.UUID);
      console.log('CHEMIN_API :', this.contexte.CHEMIN_API);
      console.log('ENVIRONNEMENT :', this.contexte.ENVIRONNEMENT);
      console.log('IdUtil :', this.contexte.IdUtil);
      console.log('NomUnique :', this.contexte.NomUnique);
      console.log('VERSION :', this.contexte.VERSION);
      return of(donneesAccueil);
    } catch (erreur) {
      this.traiterErreur(erreur);
      return of(null);
    }
  }

  private traiterErreur(erreur: unknown): void {
    this.journal.inscrire(erreur, Niveau.ERROR);
  }
}
