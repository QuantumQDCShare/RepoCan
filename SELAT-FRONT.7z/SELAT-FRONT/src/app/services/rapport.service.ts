import { Injectable } from '@angular/core';
import { rapport } from '../models/rapport.model';
import { Observable, catchError, map } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { FormeRapportEnum } from '@modeles/forme-rapport.enum';
import { repertoire } from '@modeles/repert.model';

@Injectable({
  providedIn: 'root'
})
//ToDo : connecter le service principal à l'API
export class RapportService {

  constructor(private http: HttpClient) { }

  //Obtenir l'affichage initial des répertoires de rapports
  ObtenirListeRepert(): Observable<repertoire[]> {
    return this.http.get<repertoire[]>('assets/mock/ObtenirListeRepert.json');
  }

  //Obtenir l'affichage initial des rapports
  ObtenirListeRapp(_objCritRappAfich: rapport): Observable<rapport[]> {
    return this.http.get<string[]>('assets/mock/ObtenirListeRapp.json').pipe(
      map(data => {
        const listeRapp: rapport[] = [];
        let compteurId = 0;
        const NomRapp = _objCritRappAfich.IdRapp > 4 ? 'HLI7' : _objCritRappAfich.NomRapp.substring(0, 4).trim();
        const extension = _objCritRappAfich.FormeRapp === FormeRapportEnum.EXCEL ? 'xls' : _objCritRappAfich.FormeRapp.toString();

        data.forEach(rapport => {
          if (rapport.startsWith(NomRapp) && rapport.endsWith(`.${extension}`)) {
            compteurId++;
            const rapp: rapport = {
              IdRapp: compteurId,
              NomRapp: rapport,
              FormeRapp: _objCritRappAfich.FormeRapp,
              CheminRapp: _objCritRappAfich.CheminRapp
            };
            listeRapp.push(rapp);
          }
        });

        return listeRapp;
      }),
      catchError(err => {
        throw new Error('Erreur lors de la récupération des données :', err);
      })
    );
  }

  //Consulter un des rapports
  ObtenirFichRapp(): Observable<void> {
    throw new Error('Method not implemented.');
  }

  //Exécuter un rapport
  ExecuterRapp(): Observable<void> {
    throw new Error('Method not implemented.');
  }
}