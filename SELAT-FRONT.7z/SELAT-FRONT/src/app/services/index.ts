// start:ng42.barrel
export * from './accueil-http.service';
export * from './accueil.service';
// end:ng42.barrel