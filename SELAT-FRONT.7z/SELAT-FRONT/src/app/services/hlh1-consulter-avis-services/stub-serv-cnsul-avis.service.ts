import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { ServCnsulAvisInterface } from 'src/app/serv-cnsul-avis-interface';
import { CritrTypAvis } from '@modeles/CritrTypAvis';


@Injectable({
  providedIn: 'root',
})
export class StubServCnsulAvisService implements ServCnsulAvisInterface {

  constructor(private http: HttpClient) { }

  //Permet de d'obtenir un dispensateur en fonction de l'id en parametre.
  ObtenirDispensateur(): Observable<any> {
    return this.http.get('assets/stub/ObtenirDispensateur.json');
  }
  //Permet de recuperer la liste des types avis.
  ObtenirListeTypAvis(_objCritrTypAvis: CritrTypAvis): Observable<any> {
    return this.http.get('assets/stub/ObtenirListeTypAvis.json');
  }
  //Permet de recuperer la liste des programmes/volets.
  ObtenirProgrammeVolet(): Observable<any> {
    return this.http.get('assets/stub/ObtenirProgrammeVolet.json');
  }
  //Permet de verifier si un message d'erreur est associé au codePrgmVolet selectionné.
  VerifierTypeAvis(codPrgmVolet: string): Observable<string[]> {
    const listeMsgErr: any[] = [];
    if (codPrgmVolet == 'ASA' || codPrgmVolet == 'AP' || codPrgmVolet == 'PO') {
      listeMsgErr.push("Aucun type d'avis n'existe pour le programme-volet selectionné.");
    }
    return of(listeMsgErr);
  }
  //Permet de recuperer le code associé au message d'erreur du champ input numéro dispensateur.
  ObtenirCodeErrUtilisateur() {
    return this.http.get('assets/stub/ObtenirCodeErrUtil.json');
  }
}

