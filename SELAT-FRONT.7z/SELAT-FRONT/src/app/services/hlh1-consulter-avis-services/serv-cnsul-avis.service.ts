import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { Observable } from 'rxjs';
import { ServCnsulAvisInterface } from 'src/app/serv-cnsul-avis-interface';
import { CritrTypAvis } from '@modeles/CritrTypAvis';


@Injectable({
  providedIn: 'root'
})
export class ServCnsulAvisService implements ServCnsulAvisInterface {

  constructor(private http: HttpClient) { }

  //Permet de recuperer la liste des types avis.
  ObtenirListeTypAvis(_objCritrTypAvis: CritrTypAvis): Observable<any> {
    return new Observable;
  }
  //Permet de d'obtenir un dispensateur en fonction de l'id en parametre.
  ObtenirDispensateur(): Observable<any> {
    return new Observable;
  }
  //Permet de recuperer la liste des programmes/volets.
  ObtenirProgrammeVolet(): Observable<any> {
    return new Observable;
  }
  //Permet de verifier si un message d'erreur est associé au codePrgmVolet selectionné.
  VerifierTypeAvis(codPrgmVolet: string): Observable<string[]> {
    return new Observable;
  }
  //Permet de recuperer le code associé au message d'erreur du champ input numéro dispensateur.
  ObtenirCodeErrUtilisateur() {
    return new Observable;
  }
}
