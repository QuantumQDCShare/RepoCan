import { Injectable } from '@angular/core';
import { Accueil } from '@modeles/accueil.model';

import { AccueilHttpService } from '@services';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AccueilService {

  constructor(private httpService: AccueilHttpService) { }

  obtenirAccueil(): Observable<Accueil | null> {
    const etat = this.httpService.accueil();
    return etat;
  }
}