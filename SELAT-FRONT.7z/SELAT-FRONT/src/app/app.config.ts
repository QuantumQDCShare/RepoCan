import { APP_INITIALIZER, ApplicationConfig, Injector, importProvidersFrom } from '@angular/core';
import { JournalisationService, Niveau } from './journalisation.service';
import { ContexteService } from './securite/contexte/contexte.service';
import { environment } from 'src/environments/environment';
import { ContexteModule } from './securite/contexte/contexte.module';
import { HttpClient, provideHttpClient, withFetch } from '@angular/common/http';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { routeurConfigFn } from './router.config';
import { AuthentificationModule } from './securite/authentification/authentification.module';
import { TypeAuthentification } from './securite/authentification/type-authentification.enum';
import { Router, provideRouter } from '@angular/router';
import { routes } from './app.routes';

export const appConfig: ApplicationConfig = {
  providers: [
    provideRouter(routes),
    provideHttpClient(withFetch()),
    importProvidersFrom(
      TranslateModule.forRoot({
        defaultLanguage: 'fr',
        loader: {
          provide: TranslateLoader,
          useFactory: HttpLoaderFactory,
          deps: [HttpClient]
        }
      }),
      AuthentificationModule.forRoot({ typeAuthentification: TypeAuthentification.Oidc }),
      ContexteModule,
    ),
    {
      provide: APP_INITIALIZER,
      deps: [JournalisationService, Router, Injector],
      useFactory: initialiserApp,
      multi: true
    },
    ...environment.interceptors,
  ]
};

export function initialiserApp(journal: JournalisationService, router: Router, injector: Injector): () => Promise<void | ContexteService> {
  JournalisationService.Logger = console;
  JournalisationService.ActiverTrace = !environment.production;

  return () => ContexteModule.initialiserContexte({
    configuration: environment.configuration,
    production: environment.production
  })
    .catch(erreur => {
      journal.inscrire(erreur, Niveau.ERROR);
    })
    .then(reponse => reponse)
    .finally(() => routeurConfigFn(router, injector));
}

export function HttpLoaderFactory(http: HttpClient) {
  return new TranslateHttpLoader(http);
}