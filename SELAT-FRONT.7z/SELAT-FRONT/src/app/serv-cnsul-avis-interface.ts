import { CritrTypAvis } from '@modeles/CritrTypAvis';
import { Observable } from 'rxjs';


export interface ServCnsulAvisInterface {
  //Permet de recuperer la liste des types avis.
  ObtenirListeTypAvis(_objCritrTypAvis: CritrTypAvis | undefined): Observable<any>;
  //Permet de d'obtenir un dispensateur en fonction de l'id en parametre.
  ObtenirDispensateur(): Observable<any>;
  //Permet de recuperer la liste des programmes/volets.
  ObtenirProgrammeVolet(): Observable<any>
  //Permet de verifier si un message d'erreur est associé au codePrgmVolet selectionné.
  VerifierTypeAvis(codPrgmVolet: string): Observable<string[]>
  //Permet de recuperer le code associé au message d'erreur du champ input numéro dispensateur.
  ObtenirCodeErrUtilisateur(): Observable<any>
}
