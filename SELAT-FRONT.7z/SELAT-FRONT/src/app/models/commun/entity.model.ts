export interface Entite {
    id: number;
}

export interface EntiteLookUp extends Entite {
    code: string;
    nom: string;
}
