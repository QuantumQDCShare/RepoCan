export interface ApiResultBase {
    messages: Message[];
    isValid: boolean;
}

export interface ApiResult<T> extends ApiResultBase {
    result: T;
}

export interface Message {
    content: string;
    severity: string;
}

