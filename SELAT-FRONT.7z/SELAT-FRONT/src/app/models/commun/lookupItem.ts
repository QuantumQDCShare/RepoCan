export interface LookupItem<T = any> {
    texte?: string;
    valeur?: T;
}

