import { FormeRapportEnum } from './forme-rapport.enum';

export interface repertoire {
    IdRpt: number;
    NomRpt: string;
    FormeRapp: FormeRapportEnum;
    SousRpt: boolean;
    ParenRpt: number;
    CheminRpt: string;
    NomRapp: string;
}