import { FormeRapportEnum } from '../forme-rapport.enum';

export interface CritrExecRapp {
    NomRapp: string;
    NomSrcDonne: string;
    ListeParam: string[];
    FormeRapp: FormeRapportEnum;
}