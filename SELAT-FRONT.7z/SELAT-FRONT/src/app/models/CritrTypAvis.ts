
export class CritrTypAvis{
  CodPgmVolet: string;
  constructor(CodPgmVolet:string = ''){
    this.CodPgmVolet = CodPgmVolet;
  }
}