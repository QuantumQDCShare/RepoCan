import { FormeRapportEnum } from './forme-rapport.enum';

export interface rapport {
    IdRapp: number;
    NomRapp: string;
    FormeRapp: FormeRapportEnum;
    CheminRapp: string;
}