export interface Accueil {
  uid: string;
}
