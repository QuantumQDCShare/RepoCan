import { Observable } from 'rxjs';

export interface ReponseResolver<T> {
  reponse$?: Observable<T>;
  reponse: T;
  erreur?: unknown;
}
