export enum FormeRapportEnum {
    PDF = 'pdf',
    EXCEL = 'xls'
}