/* eslint-disable @typescript-eslint/no-explicit-any */
/*******************************************
/* Note du développeur - 2021/07/16
/*******************************************
 * Exception volontaire pour l'enum dans le même fichier :
 * Pour le moment, j'aimerais faire un exception et garder ça ainsi. Je sais pas encore comment la
 * journalisation va rester/évoluer dans le temps. Va t'elle avoir son propre module? Je la garde en
 * injection ou je bâtis un singleton? Il me faut la traduction? Donc tant que je ne sais pas comment
 * l'architecture va se diriger, je veux la garder compacte dans un seul fichier pour ne pas avoir à fouiller.
 * Le jour que la vrai version va être fait ou que je saurai quoi faire avec, ça va sortir dans un enum. Pour
 * l'heure, je ne veux pas polluer le répertoire avec ça.
 *
 * En bonus aussi est que si on en a besoin dans un autre projet, on a juste a coller journalisation.service.ts
 * dans le répertoire racine d'Angular pour que ça marche.
 *******************************************/
import { TranslateService } from '@ngx-translate/core';
import { Injectable } from '@angular/core';
import { first } from 'rxjs/operators';

export enum Niveau {
  ERROR = 'error',
  INFO = 'info',
  DEBUG = 'debug',
  WARN = 'warn'
}

interface Logger {
  error(message?: any, ...optionalParams: any[]): void;
  info(message?: any, ...optionalParams: any[]): void;
  debug(message?: any, ...optionalParams: any[]): void;
  warn(message?: any, ...optionalParams: any[]): void;
}

type ErreurConnue = { code?: string, params?: any };

@Injectable({ providedIn: 'root' })
export class JournalisationService {
  static Logger: Logger | undefined;
  static ActiverTrace = false;

  static tracer(message: string): void {
    const logger = JournalisationService.Logger;
    if (JournalisationService.ActiverTrace && logger) {
      const tamponTemporel = new Date().toLocaleString();
      logger.info(`${tamponTemporel} - ${message}`);
    }
  }

  constructor(private translate: TranslateService) { }

  inscrire<ErreurInconnue>(erreur: ErreurInconnue | ErreurConnue, niveau = Niveau.DEBUG): void {
    const logger = JournalisationService.Logger;
    if (logger) {
      const tamponTemporel = new Date().toLocaleString();
      if (typeof (erreur) === 'string') {
        this.inscrireMessageErreur(logger, tamponTemporel, erreur, niveau);
      } else {
        this.inscrireObjetErreur(logger, tamponTemporel, erreur, niveau);
      }
    }
  }

  tracer(message: string): void {
    JournalisationService.tracer(message);
  }

  private inscrireMessageErreur(logger: Logger, tamponTemporel: any, messageErreur: string, niveau: Niveau): void {
    logger[niveau](`${tamponTemporel} - ${messageErreur}`);
  }

  private inscrireObjetErreur<ErreurInconnue>(
    logger: Logger,
    tamponTemporel: any,
    objetErreur: ErreurInconnue | ErreurConnue,
    gravite: Niveau
  ): void {
    if ((objetErreur as any).code) {
      const erreurTraduisible = objetErreur as ErreurConnue;
      this.translate.get(erreurTraduisible.code ?? '', erreurTraduisible.params)
        .pipe(first())
        .subscribe(traduction => this.inscrireMessageErreur(logger, tamponTemporel, traduction, gravite));
    } else {
      this.inscrireMessageErreur(logger, tamponTemporel, JSON.stringify(objetErreur), gravite);
      logger[gravite](objetErreur);
    }
  }
}
