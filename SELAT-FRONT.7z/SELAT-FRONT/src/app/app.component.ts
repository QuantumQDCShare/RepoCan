import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { PermissionsService } from './auth.guard';
import { BanniereHautComponent } from './partage/banniere-haut/banniere-haut.component';
import { MenuGaucheComponent } from './partage/menu-gauche/menu-gauche.component';
import { BanniereBasComponent } from './partage/banniere-bas/banniere-bas.component';


@Component({
  selector: 'app-root',
  standalone: true,
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss',
  imports: [RouterOutlet, BanniereHautComponent, MenuGaucheComponent, BanniereBasComponent],
  providers: [PermissionsService]
})
export class AppComponent {
  title = 'HLI5_V2CnsulRappAn';
}
