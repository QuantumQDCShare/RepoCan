import { CommonModule } from '@angular/common';
import { Component, Inject, Input } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CritrTypAvis } from '@modeles/CritrTypAvis';
import { Hla5ContexteTravailComponent } from 'src/app/composants-communs/hla5-contexte-travail/hla5-contexte-travail.component';
import { ServCnsulAvisInterface } from 'src/app/serv-cnsul-avis-interface';
import { StubServCnsulAvisService } from 'src/app/services/hlh1-consulter-avis-services/stub-serv-cnsul-avis.service';

@Component({
  selector: 'rat-generer-avis',
  standalone: true,

  imports: [CommonModule, FormsModule, ReactiveFormsModule, Hla5ContexteTravailComponent],
  providers: [{ provide: 'ServCnsulAvisInterface', useClass: StubServCnsulAvisService }],
  templateUrl: './generer-avis.component.html',
  styleUrl: './generer-avis.component.scss'
})
export class GenererAvisComponent {

  hlh1Form: FormGroup;
   @Input() CodeProgmVolet: string = '';
   @Input() blnMsgTraitSeverHaut: boolean = true;
  ListeTypesAvis: any[] = [];
  ListeDisp: any[] = [];
  ListeMessErr: any[] = [];
  CodeErr: string = "";
  IdDisp: number = 0;
  Message: string = '';
  critrAvisTest: CritrTypAvis | undefined;
  choixExtensionPrecedent: string;

  constructor(@Inject('ServCnsulAvisInterface') private service: ServCnsulAvisInterface, private formulaireHlh1: FormBuilder) {
    this.hlh1Form = this.formulaireHlh1.group({
      identifiantDisp: [{ value: '', disabled: true }],
      NumDisp: [{ value: '', disabled: true }, [Validators.required, Validators.minLength(6), Validators.maxLength(6), Validators.pattern(/^[0-9]*$/)]],
      choixExtension: ['pdf'],
      Dispensaire: [true],
    });
    this.choixExtensionPrecedent = this.hlh1Form.get('choixExtension')?.value;
  }
  ngOnInit(): void {

    this.hlh1Form.get('Dispensaire')?.valueChanges.subscribe(cocher => {
      const numDispControl = this.hlh1Form.get('NumDisp');
      const nomDispControl = this.hlh1Form.get('identifiantDisp');
      if (cocher) {
        this.DesactiverInputDisp(numDispControl, nomDispControl);
        this.ReinitialiserInputDisp(numDispControl, nomDispControl);
      } else {
        this.ActiverInputDisp(numDispControl, nomDispControl);
      }
    });

    this.hlh1Form.get('choixExtension')?.valueChanges.subscribe(value => {
      if (this.choixExtensionPrecedent !== value) {
        this.hlh1Form.get('choixExtension')?.setValue(value, { emitEvent: false });
        this.choixExtensionPrecedent = value;
        console.log(this.hlh1Form.get('choixExtension')?.value);
      }
    });

    this.hlh1Form.get('NumDisp')?.valueChanges.subscribe(value => {
      this.hlh1Form.get('identifiantDisp')?.setValue("");
      this.service.ObtenirDispensateur().subscribe({
        next: (data: any) => {
          this.ListeDisp = data.dispensateurs.filter((disp: any) => disp.idDisp == value);
          if (this.ListeDisp.length > 0) {
            const nomDispValeur = this.ListeDisp[0].nomDisp;
            this.hlh1Form.get('identifiantDisp')?.setValue(nomDispValeur);
          }
          if (this.hlh1Form.get('NumDisp')?.errors?.['required']) {
            this.ObtenirMessErrUtilisateur();
          }
        },
        error: (err: any) => {
          console.error('Erreur lors du chargement du fichier JSON :', err);
        },
      });
    });

    this.service.ObtenirListeTypAvis(this.critrAvisTest).subscribe({
      next: (data: any) => {
        this.ListeTypesAvis = data.TypesAvis;
      },
      error: (err: any) => {
        console.error('Erreur lors du chargement du fichier JSON :', err);
      },
    });
  }

  ObtenirMessErrUtilisateur() {
    this.service.ObtenirCodeErrUtilisateur().subscribe({
      next: (data: any) => {
        this.ListeMessErr = data.CodeErrUtil;
        this.CodeErr = this.ListeMessErr[0].CodeErr;
      },
      error: (err: any) => {
        console.error('Erreur lors du chargement du fichier JSON :', err);
      },
    });
  }

  ActiverInputDisp(inputNumDisp: any, inputNomDisp: any) {
    inputNumDisp.enable();
    inputNomDisp.enable();
  }

  DesactiverInputDisp(inputNumDisp: any, inputNomDisp: any) {
    inputNumDisp.disable();
    inputNomDisp.disable();
  }

  ReinitialiserInputDisp(inputNumDisp: any, inputNomDisp: any) {
    inputNumDisp.reset();
    inputNomDisp.reset();
  }

  GenererAvis() {
    if (this.hlh1Form.valid) {
      console.log('Formulaire Soumis!');
    } else {
      console.log('Formulaire non soumis');
    }
  }

  // Le code est commenté en attente d'une décision d'architecture.
  /*GenererURLRapp(_objDonnees: WPDataCnsulAvis){
    let strNomRapp : string;
    let strNomSrcDonne : string;
    let strParams : string;
    let colctAppSettingParams : string[];
    let arElemParam : string[];
    let strNomParam : string;
    let strValParam : string;
    let strRappAvisValue : string;
    let objRappAvis : RappAvis;

    strNomRapp = this.ObtenirValAppSettingRapp(Constante.strAppSettingNomRapp, _objDonnees);
    strNomSrcDonne = this.ObtenirValAppSettingRapp(Constante.strAppSettingNomSrcDonne, _objDonnees);
    strParams = this.ObtenirValAppSettingRapp(Constante.strAppSettingParams, _objDonnees);

    objRappAvis = new RappAvis();

    objRappAvis.shrtSrcRapp = 2;
    objRappAvis.intFormeRapp = _objDonnees.intFormeAvis;
    objRappAvis.strNomRapp = strNomRapp;
    objRappAvis.strNomSrcDonne = strNomSrcDonne;
    objRappAvis.strNomFichSauvRapp = _objDonnees.strNomFichSauvRapp;

    colctAppSettingParams = strParams.split(";");
    colctAppSettingParams.forEach(strAppSettingParam => {
      arElemParam = strAppSettingParam.split("=");
      strNomParam = arElemParam[0];
      strValParam = this.ObtenirValParam(arElemParam[1], _objDonnees);
      objRappAvis.colctParam[strNomParam] = strValParam;

      //strRappAvisValue = UtltrAfichCtrl.JSONExtn.Serialiser(Of RappAvis)(objRappAvis)
      //hfldUrlRapp.Value = String.Format("{0}?rappexec={1}", "HLI5_CnsulRapp.aspx", strRappAvisValue)

    });
  }

  ObtenirValAppSettingRapp(_strNomAppSetting: String, _objDonnees: WPDataCnsulAvis): string{
    let strValAppSetting: string;
    let strFormeRapp: string = "";

    switch(_objDonnees.intFormeAvis){
      case 2:
        strFormeRapp = "CSV";
        break;
      case 2:
        strFormeRapp = "PDF";
        break;
    }
    _strNomAppSetting =`${_strNomAppSetting} ${_objDonnees.strDesTypAvis} ${strFormeRapp}`;
    strValAppSetting = this.AppSettings(_strNomAppSetting);

    if(strValAppSetting == null){
      throw new Error(`${Constante.strExAppSettingManquant}, ${_strNomAppSetting}, ${this.ContxExec.Envir}`);
    }
    return strValAppSetting;
  };
  
  ObtenirValParam(_strElemValParam: string, _objDonnees: WPDataCnsulAvis): string{
    let strValParam: string = "";

    switch(_strElemValParam){
      case "noDisp":
      strValParam = _objDonnees.strNoDisp;
      break;
      case "{NoSeqDisp}":
        if(_objDonnees.intNoSeqDisp){
          strValParam = _objDonnees.intNoSeqDisp.toString();
        }
        else if( _objDonnees.objContxTrav.lngNoSeqDisp == null){
          strValParam = _objDonnees.objContxTrav.lngNoSeqDisp;
        }
        break;

      case "{NoSeqPgmVolet}":
        strValParam = _objDonnees.objContxTrav.lngNoSeqPgmVolet.toString();
        break;

      case "{IdUtil}":
        strValParam = "0635"; // ContxExec.Util.IdUtil
        break;

      default:
        strValParam = _strElemValParam;  
    }
    return strValParam;
  }*/
}
