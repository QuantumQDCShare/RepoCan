import { NavigationError, Router } from '@angular/router';
import { Injector } from '@angular/core';
import { JournalisationService, Niveau } from 'src/app/journalisation.service';
import { AuthentificationOidcHooks } from 'src/app/securite/authentification';
import { AppStates } from './app.states.enum';
import { AuthentificationOidcService } from './securite/authentification/oidc/authentification-oidc.service';

export function routeurConfigFn(router: Router, injector: Injector): void {
  accrocherHooks(router, injector);

  router.events.subscribe(event => {
    if (event instanceof NavigationError) {
      const journal = injector.get(JournalisationService);
      journal.inscrire(event.error, Niveau.ERROR);
      console.log('erreur connexion : ', event.error);
      router.navigate([AppStates.PageErreurTechnique]);
    }
  });
}

function accrocherHooks(router: Router, injector: Injector): void {
  const journalService = injector.get(JournalisationService);
  AuthentificationOidcHooks.connectionOIDC(
    {
      etatPrincipal: AppStates.PagePrincipal,
      etatErreurAuthentification: AppStates.PageErreurAuthentification,
      etatErreurTechnique: AppStates.PageErreurTechnique,
      etatIntrouvable: AppStates.PageIntrouvable
    },
    injector.get(AuthentificationOidcService),
    journalService,
    router
  );
}
