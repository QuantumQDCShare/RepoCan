import { Injectable, inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { AuthentificationFacadeService } from './securite/authentification/authentification-facade.service';
import { StatutAuthentification } from './securite/authentification/statut-authentification.enum';
import { AppStates } from './app.states.enum';
import { CodeErreur } from './code-erreur.enum';
import { JournalisationService, Niveau } from './journalisation.service';
import { AutorisationService } from './securite/autorisation/autorisation.service';

@Injectable({ providedIn: 'root' })
export class PermissionsService {
  canActivate(authService: AuthentificationFacadeService, router: Router): boolean {
    if (authService.Etat !== StatutAuthentification.Authentifie) {
      router.navigate([AppStates.PageErreurAuthentification], { queryParams: { code: CodeErreur.HLI5_1001 } });
      return false;
    }
    return true;
  }

  //Corriger le problème, on ne reçoit pas de rôle depuis le back-end lors de l'authentification, ce qui est un problème
  canMatch(
    authService: AuthentificationFacadeService, 
    router: Router, autorisationService: AutorisationService, 
    journal: JournalisationService
  ): boolean {
    const hasAccess = autorisationService.verifierRoles({
      jeton: authService.recupererCopieJeton(),
      surRoleRefuse: raisonRefus => {
        journal.inscrire(raisonRefus, Niveau.INFO);
        router.navigate([AppStates.PageErreurAuthentification], { queryParams: { code: CodeErreur.HLI5_1001 } });
      }
    });
    return hasAccess;
  }
}

export const authGuard: CanActivateFn = () => {
  return inject(PermissionsService).canActivate(inject(AuthentificationFacadeService), inject(Router));
};

export const roleGuard: CanActivateFn = () => {
  return inject(PermissionsService).canMatch(
    inject(AuthentificationFacadeService), 
    inject(Router), inject(AutorisationService), 
    inject(JournalisationService)
  );
};
