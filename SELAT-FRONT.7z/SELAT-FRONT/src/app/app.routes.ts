import { Routes } from '@angular/router';
import { PagePrincipalComponent } from './hli5-consulter-rapport/page-principal/page-principal.component';
import { IntrouvableComponent } from './pages/page-introuvable/introuvable.component';
import { authGuard } from './auth.guard';
import { ErreurAuthentificationComponent } from './pages/erreur-authentification/erreur-authentification.component';
import { ErreurTechniqueComponent } from './pages/erreur-technique/erreur-technique.component';
import { GenererAvisComponent } from './hlh1-consulter-avis/generer-avis/generer-avis.component';
import { AccueilComponent } from './accueil/accueil.component';


export const routes: Routes = [

  // Pages services techniques
  { path: 'pageErreurAuthentification', component: ErreurAuthentificationComponent },
  { path: 'pageErreurTechnique', component: ErreurTechniqueComponent },
  //{ path: 'pageIntrouvable', component: IntrouvableComponent },

  // pages composants 
  { path: 'AccueilComponent', component: AccueilComponent, canActivate: [authGuard] },
  { path: 'consulter-avis', component: GenererAvisComponent },

  { path: 'consulter-rapport', component: PagePrincipalComponent},
  { path: '', redirectTo: 'AccueilComponent', pathMatch: 'full' },
 // { path: '**', redirectTo: 'pageIntrouvable' }
];
