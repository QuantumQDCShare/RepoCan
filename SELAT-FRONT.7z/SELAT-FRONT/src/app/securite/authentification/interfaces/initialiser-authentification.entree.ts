export interface InitialiserAuthentificationEntree {
  UrlSource: string;
  Oidc?: {
    IdClient: string;
    UriHoteRedirection: string;
    ScopeAPI: string;
  };
}
