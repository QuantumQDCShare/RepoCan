import { Observable } from 'rxjs';

import { StatutAuthentification } from '../statut-authentification.enum';
import { Jeton } from '../modeles/jeton';
import { InitialiserAuthentificationEntree } from './initialiser-authentification.entree';

export interface AuthentificationService {
  Statut: StatutAuthentification;
  ChangementStatut$: Observable<StatutAuthentification>;
  initialiser(params: InitialiserAuthentificationEntree): Observable<unknown>;
  connecter(): Observable<unknown>;
  deconnecter(): Observable<unknown>;
  obtenirInfosJeton(): Jeton | undefined;
}
