import { ModuleWithProviders, NgModule } from '@angular/core';
import { AuthentificationOidcService } from './oidc/authentification-oidc.service';
import { AuthentificationFacadeService } from './authentification-facade.service';
import { TypeAuthentification } from './type-authentification.enum';

//On peut supprimer le fichier
@NgModule({
  declarations: [],
  imports: [],
  exports: [],
  providers: [
    AuthentificationOidcService,
    AuthentificationFacadeService,
    { provide: TypeAuthentification, useValue: TypeAuthentification.Differee } // Provider par défaut si forRoot non appelé
  ]
})

export class AuthentificationModule {
  static forRoot(params?: { typeAuthentification: TypeAuthentification }): ModuleWithProviders<AuthentificationModule> {
    if (params?.typeAuthentification) {
      return {
        ngModule: AuthentificationModule,
        providers: [
          { provide: TypeAuthentification, useValue: params.typeAuthentification }
        ]
      };
    } else {
      return { ngModule: AuthentificationModule };
    }
  }
}
