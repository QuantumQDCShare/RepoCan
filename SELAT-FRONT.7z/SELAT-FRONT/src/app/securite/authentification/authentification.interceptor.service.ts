import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';

import { ContexteService } from 'src/app/securite/contexte';

export abstract class AuthentificationInterceptorService implements HttpInterceptor {

  constructor(private contexteservice: ContexteService) { }
  abstract intercept(req: HttpRequest<never>, next: HttpHandler): Observable<HttpEvent<unknown>>;

  protected estInterceptable(url: string): boolean {
    return this.estAppelRessourceExterne(url) &&
      !this.estAppelRecuperationJeton(url);
  }

  protected estAppelRessourceExterne(url: string): boolean {
    return !url.startsWith('/assets/') && !url.startsWith('..');
  }

  protected estAppelRecuperationJeton(url: string): boolean {
    if (this.contexteservice.RacineClient) {
      return url.includes('/token') || url.includes(this.contexteservice.RacineClient);
    }
    return url.includes('/token');
  }
}
