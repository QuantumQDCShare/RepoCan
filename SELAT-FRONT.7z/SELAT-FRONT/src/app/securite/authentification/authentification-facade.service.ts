import { Injectable, Injector, EventEmitter } from '@angular/core';
import { Observable, of } from 'rxjs';
import { AuthentificationService } from './interfaces/authentification.service';
import { AuthentificationOidcService } from './oidc/authentification-oidc.service';
import { Jeton } from './modeles/jeton';
import { StatutAuthentification } from './statut-authentification.enum';
import { InitialiserAuthentificationEntree } from './interfaces/initialiser-authentification.entree';
import { TypeAuthentification } from './type-authentification.enum';

@Injectable()
export class AuthentificationFacadeService {
  private authentificationService: AuthentificationService | undefined;
  get Etat(): StatutAuthentification {
    return this.authentificationService ? this.authentificationService.Statut : StatutAuthentification.ErreurTechnique;
  }
  private changementEtat$ = new EventEmitter<StatutAuthentification>();
  ChangementEtat$: Observable<StatutAuthentification>;

  constructor(private injector: Injector, typeAuthentification: TypeAuthentification) {
    this.ChangementEtat$ = this.changementEtat$.asObservable();
    this.obtenirServiceAuthentification(typeAuthentification);
    this.souscrireChangementEtat();
  }

  private obtenirServiceAuthentification(typeAuthentification?: TypeAuthentification): void {
    if (typeAuthentification) {
      switch (typeAuthentification) {
        case TypeAuthentification.Oidc: this.authentificationService = this.injector.get(AuthentificationOidcService); break;
      }
    }
  }

  private souscrireChangementEtat(): void {
    this.authentificationService?.ChangementStatut$.subscribe(etat => {
      this.changementEtat$.next(etat);
    });
  }

  initialiserAuthentification(params: InitialiserAuthentificationEntree): Observable<unknown> {
    this.verifierAuthentificationService(params);
    return this.authentificationService ? this.authentificationService.initialiser(params) : of({});
  }

  private verifierAuthentificationService(params: InitialiserAuthentificationEntree): void {
    if (!params.Oidc) {
      this.changementEtat$.next(StatutAuthentification.ErreurTechnique);
    } else if (!this.authentificationService) {
      this.obtenirServiceAuthentification(TypeAuthentification.Oidc);
      this.souscrireChangementEtat();
    }
  }

  recupererCopieJeton(): Jeton | undefined {
    console.log('recupererCopieJeton');
    const jetonCourant = this.authentificationService?.obtenirInfosJeton();
    if (jetonCourant) {
      const jeton = new Jeton();
      Object.assign(jeton, jetonCourant);
      return jeton;
    }
    return undefined;
  }

  deconnecter(): Observable<unknown> {
    return this.authentificationService ? this.authentificationService.deconnecter() : of({});
  }
}
