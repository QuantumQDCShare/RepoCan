import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed, fakeAsync, tick, inject } from '@angular/core/testing';
import { JwtHelperService } from '@auth0/angular-jwt';
import { v4 as UUID } from 'uuid';
import { MockBuilder, MockService } from 'ng-mocks';
import { User, UserManager } from 'oidc-client-ts';
import { createSpyFromClass } from 'jasmine-auto-spies';

import { Constantes } from '../constantes';
import { InitialiserAuthentificationEntree } from '../interfaces/initialiser-authentification.entree';
import { Jeton } from '../modeles';
import { StatutAuthentification } from '../statut-authentification.enum';
import { AuthentificationOidcService } from './authentification-oidc.service';

// ToDo - Trouver pourquoi ces tests échouent la moitié du temps dans Azure
xdescribe(`Service: AuthentificationOidcService`, () => {
  let service: AuthentificationOidcService;
  let spies: TestSpies;

  beforeEach(() => {
    spies = new TestSpies();
    const ngModule = MockBuilder(AuthentificationOidcService)
      .keep(HttpClientTestingModule)
      .build();
    TestBed.configureTestingModule(ngModule);
    service = Object.assign(TestBed.inject(AuthentificationOidcService), {
      gestionnaireUtilisateur: MockService(UserManager, spies.gestionnaireUtilisateur),
      jwtHelper: MockService(JwtHelperService, spies.jwtHelper)
    });
  });

  describe(`Initialisation`, () => {
    it(`doit être créé`, () => {
      expect(service).toBeTruthy();
    });

    it(`doit avoir une seule instance`, inject([AuthentificationOidcService], (serviceLocal: AuthentificationOidcService) => {
      expect(serviceLocal).toBeTruthy();
      expect(service).toBeTruthy();
      expect(service).toBe(serviceLocal);
    }));

    it(`doit être à l'état NonAuthentifie`, () => {
      expect(service.Statut).toEqual(StatutAuthentification.NonAuthentifie);
    });
  });

  describe(`Fonctions: `, () => {
    let fixtureParamEntree: InitialiserAuthentificationEntree;
    const recupererGestionnaireUtilisateur = <T>(instance: T) => (instance as { gestionnaireUtilisateur: T }).gestionnaireUtilisateur;

    beforeEach(() => {
      fixtureParamEntree = new FixtureInitialiserAuthentificationEntree();
    });

    describe(`initialiser`, () => {
      it(`doit initialiser le gestionnaire utilisateur SI ce dernier n'existe pas ET les paramètres Oidc sont reçus`, () => {
        service = new AuthentificationOidcService();
        const gestionnaireInitial = recupererGestionnaireUtilisateur(service);

        service.initialiser(fixtureParamEntree);
        const gestionnaireFinal = recupererGestionnaireUtilisateur(service);

        expect(gestionnaireFinal).not.toBe(gestionnaireInitial);
      });

      // ToDo - Trouver pourquoi ce test échoue de temps en temps
      xit(`ne doit pas initialiser le gestionnaire utilisateur SI ce dernier existe`, () => {
        const gestionnaireInitial = recupererGestionnaireUtilisateur(service);

        service.initialiser(fixtureParamEntree);
        const gestionnaireFinal = recupererGestionnaireUtilisateur(service);

        expect(gestionnaireInitial).toBe(gestionnaireFinal);
      });

      // ToDo - Trouver pourquoi ce test échoue de temps en temps
      xit(`ne doit pas initialiser le gestionnaire utilisateur SI les paramètres Oidc ne sont pas reçus`, () => {
        service = new AuthentificationOidcService();
        delete fixtureParamEntree.Oidc;

        service.initialiser(fixtureParamEntree);
        const gestionnaireFinal = recupererGestionnaireUtilisateur(service);

        expect(gestionnaireFinal).toBeUndefined();
      });

      it(`doit invoquer la connexion SI l'URL de l'application est la racine '/'`, fakeAsync(() => {
        spies.gestionnaireUtilisateur.signinRedirect.and.resolveTo();
        spyOnProperty(AuthentificationOidcService, 'UrlNavigateur', 'get').and.returnValue('/');

        service.initialiser({ UrlSource: UUID() });
        tick();

        expect(spies.gestionnaireUtilisateur.signinRedirect).toHaveBeenCalled();
      }));

      it(`ne doit pas invoquer la connexion SI l'URL de l'application n'est pas la racine '/'`, fakeAsync(() => {
        spies.gestionnaireUtilisateur.signinRedirect.and.resolveTo();
        spyOnProperty(AuthentificationOidcService, 'UrlNavigateur', 'get').and.returnValue(`/${UUID()}`);

        service.initialiser({ UrlSource: UUID() });
        tick();

        expect(spies.gestionnaireUtilisateur.signinRedirect).not.toHaveBeenCalled();
      }));
    });

    describe(`connecter`, () => {
      it(`doit invoquer 'signinRedirect' de la librairie Oidc`, () => {
        const spySigninRedirect = spies.gestionnaireUtilisateur.signinRedirect.and.resolveTo();

        service.connecter();

        expect(spySigninRedirect).toHaveBeenCalled();
      });
    });

    describe(`estConnecte`, () => {
      it(`doit invoquer 'getUser' de la librairie Oidc`, () => {
        const spyGetUser = spies.gestionnaireUtilisateur.getUser.and.resolveTo();

        service.estConnecte();

        expect(spyGetUser).toHaveBeenCalled();
      });

      it(`doit retourner 'vrai' SI l'utilisateur est valide`, fakeAsync(() => {
        const mockUtilisateur = MockService(User);
        spies.gestionnaireUtilisateur.getUser.and.resolveTo(mockUtilisateur);
        let resultatTest!: boolean;

        service.estConnecte().then(resultat => resultatTest = resultat);
        tick();

        expect(resultatTest).toBeTrue();
      }));

      it(`ne doit pas lancer de notification ET retourner 'vrai' SI aucun changement au niveau de l'utilisateur`, fakeAsync(() => {
        const user = MockService(User);
        spies.gestionnaireUtilisateur.getUser.and.resolveTo(user);
        spies.gestionnaireUtilisateur.signinRedirectCallback.and.resolveTo(user);
        let notificationRecue: boolean;
        let resultatTest = false;

        service.ChangementStatut$.subscribe(() => notificationRecue = true);
        service.completerConnexion();
        tick();
        notificationRecue = false;
        service.estConnecte().then(resultat => resultatTest = resultat);
        tick();

        expect(resultatTest).toBeTrue();
        expect(notificationRecue).toBeFalse();
      }));

      it(`doit retourner 'faux' SI le nouvel utilisateur n'existe pas`, fakeAsync(() => {
        spies.gestionnaireUtilisateur.getUser.and.resolveTo();
        let resultatTest!: boolean;

        service.estConnecte().then(resultat => resultatTest = resultat);
        tick();

        expect(resultatTest).toBeFalse();
      }));

      it(`doit retourner 'faux' SI l'utilisateur est expiré`, fakeAsync(() => {
        const mockUtilisateur = MockService(User, { expired: true });
        spies.gestionnaireUtilisateur.getUser.and.resolveTo(mockUtilisateur);
        let resultatTest!: boolean;

        service.estConnecte().then(resultat => resultatTest = resultat);
        tick();

        expect(resultatTest).toBeFalse();
      }));

      it(`doit émettre le statut 'NonAuthentifie' SI l'utilisateur n'existe pas`, fakeAsync(() => {
        spies.gestionnaireUtilisateur.getUser.and.resolveTo();
        let statutObtenu!: StatutAuthentification;

        service.ChangementStatut$.subscribe(resultat => statutObtenu = resultat);
        service.estConnecte();
        tick();

        expect(service.Statut).toEqual(statutObtenu);
        expect(statutObtenu).toEqual(StatutAuthentification.NonAuthentifie);
      }));

      it(`doit émettre le statut 'NonAuthentifie' SI le nouvel utilisateur est expiré`, fakeAsync(() => {
        const mockUtilisateur = MockService(User, { expired: true });
        spies.gestionnaireUtilisateur.getUser.and.resolveTo(mockUtilisateur);
        let statutObtenu!: StatutAuthentification;

        service.ChangementStatut$.subscribe(resultat => statutObtenu = resultat);
        service.estConnecte();
        tick();

        expect(service.Statut).toEqual(statutObtenu);
        expect(statutObtenu).toEqual(StatutAuthentification.NonAuthentifie);
      }));
    });

    describe(`completerConnexion`, () => {
      it(`doit invoquer 'signinRedirectCallback' de la librairie Oidc`, () => {
        const spySigninRedirectCallback = spies.gestionnaireUtilisateur.signinRedirectCallback.and.resolveTo();

        service.completerConnexion();

        expect(spySigninRedirectCallback).toHaveBeenCalled();
      });

      it(`doit retourner l'utilisateur obtenu de la librairie Oidc`, fakeAsync(() => {
        const mockUtilisateur = MockService(User);
        spies.gestionnaireUtilisateur.signinRedirectCallback.and.resolveTo(mockUtilisateur);
        let utilisateurObtenu!: User | Error;

        service.completerConnexion().then(resultat => utilisateurObtenu = resultat);
        tick();

        expect(utilisateurObtenu).toBe(mockUtilisateur);
      }));

      it(`doit émettre le statut 'Authentifie' SI l'utilisateur est valide`, fakeAsync(() => {
        const mockUtilisateur = MockService(User);
        spies.gestionnaireUtilisateur.signinRedirectCallback.and.resolveTo(mockUtilisateur);
        let statutObtenu!: StatutAuthentification;

        service.ChangementStatut$.subscribe(resultat => statutObtenu = resultat);
        service.completerConnexion();
        tick();

        expect(service.Statut).toEqual(statutObtenu);
        expect(statutObtenu).toEqual(StatutAuthentification.Authentifie);
      }));

      it(`doit émettre le statut 'NonAuthentifie' SI l'utilisateur n'existe pas`, fakeAsync(() => {
        spies.gestionnaireUtilisateur.signinRedirectCallback.and.resolveTo();
        let statutObtenu!: StatutAuthentification;

        service.ChangementStatut$.subscribe(resultat => statutObtenu = resultat);
        service.completerConnexion();
        tick();

        expect(service.Statut).toEqual(statutObtenu);
        expect(statutObtenu).toEqual(StatutAuthentification.NonAuthentifie);
      }));

      it(`doit émettre le statut 'NonAuthentifie' SI l'utilisateur est expiré`, fakeAsync(() => {
        const mockUtilisateur = MockService(User, { expired: true });
        spies.gestionnaireUtilisateur.signinRedirectCallback.and.resolveTo(mockUtilisateur);
        let statutObtenu!: StatutAuthentification;

        service.ChangementStatut$.subscribe(resultat => statutObtenu = resultat);
        service.completerConnexion();
        tick();

        expect(service.Statut).toEqual(statutObtenu);
        expect(statutObtenu).toEqual(StatutAuthentification.NonAuthentifie);
      }));

      it(`doit émettre le statut 'ErreurAuthentification' SI une erreur d'authentification est détectée`, fakeAsync(() => {
        let statutObtenu!: StatutAuthentification;
        const mockErreur = new Error(Constantes.OIDC.CODES_ERREUR_AUTHENTIFICATION[0]);
        spies.gestionnaireUtilisateur.signinRedirectCallback.and.rejectWith(mockErreur);

        service.ChangementStatut$.subscribe(resultat => statutObtenu = resultat);
        service.completerConnexion();
        tick();

        expect(service.Statut).toEqual(statutObtenu);
        expect(statutObtenu).toEqual(StatutAuthentification.ErreurAuthentification);
      }));

      it(`doit émettre le statut 'ErreurTechnique' SI une erreur autre qu'authentification est détectée`, fakeAsync(() => {
        let statutObtenu!: StatutAuthentification;
        const mockErreur = new Error(UUID());
        spies.gestionnaireUtilisateur.signinRedirectCallback.and.rejectWith(mockErreur);

        service.ChangementStatut$.subscribe(resultat => statutObtenu = resultat);
        service.completerConnexion();
        tick();

        expect(service.Statut).toEqual(statutObtenu);
        expect(statutObtenu).toEqual(StatutAuthentification.ErreurTechnique);
      }));

      it(`doit retourner le message d'erreur SI une erreur est détectée`, fakeAsync(() => {
        let erreurObtenue!: Error | User;
        const mockErreur = new Error(UUID());
        spies.gestionnaireUtilisateur.signinRedirectCallback.and.rejectWith(mockErreur);

        service.completerConnexion().then(erreur => erreurObtenue = erreur);
        tick();

        expect(erreurObtenue).toEqual(mockErreur);
      }));

    });

    describe(`deconnecter`, () => {
      it(`doit invoquer 'signoutRedirect' de la librairie Oidc`, fakeAsync(() => {
        const spyDeconnexion = spies.gestionnaireUtilisateur.signoutRedirect.and.resolveTo();

        service.deconnecter().subscribe();
        tick();

        expect(spyDeconnexion).toHaveBeenCalled();
      }));
    });

    describe(`completerDeconnexion`, () => {
      it(`doit invoquer 'signoutRedirectCallback' de la librairie Oidc`, () => {
        const spyGetUser = spies.gestionnaireUtilisateur.signoutRedirectCallback.and.resolveTo();

        service.completerDeconnexion();

        expect(spyGetUser).toHaveBeenCalled();
      });

      it(`doit émettre le statut 'Deconnecte'`, fakeAsync(() => {
        let statutObtenu!: StatutAuthentification;

        service.ChangementStatut$.subscribe(resultat => statutObtenu = resultat);
        service.completerDeconnexion();
        tick();

        expect(service.Statut).toEqual(statutObtenu);
        expect(statutObtenu).toEqual(StatutAuthentification.Deconnecte);
      }));
    });

    describe(`obtenirJeton`, () => {
      let fakeJeton: string;

      beforeEach(() => {
        fakeJeton = UUID();
      });

      it(`doit invoquer 'getUser' de la librairie Oidc`, () => {
        const spyGetUser = spies.gestionnaireUtilisateur.getUser.and.resolveTo();

        service.obtenirJeton();

        expect(spyGetUser).toHaveBeenCalled();
      });

      it(`doit retourner le jeton de l'utilisateur SI l'utilisateur n'est pas expiré`, fakeAsync(() => {
        const utilisateur = MockService(User, {
          access_token: fakeJeton
        });
        spies.gestionnaireUtilisateur.getUser.and.resolveTo(utilisateur);
        let jeton!: string | null;

        service.obtenirJeton().then(resultat => jeton = resultat);
        tick();

        expect(jeton).toEqual(fakeJeton);
      }));

      it(`ne doit pas retourner le jeton de l'utilisateur SI l'utilisateur est expiré`, fakeAsync(() => {
        spies.gestionnaireUtilisateur.getUser.and.resolveTo(null);
        let jeton!: string | null;

        service.obtenirJeton().then(resultat => jeton = resultat);
        tick();

        expect(jeton).toBeFalsy();
      }));

      it(`ne doit pas retourner le jeton de l'utilisateur SI l'utilisateur n'existe pas'`, fakeAsync(() => {
        const utilisateur = MockService(User, {
          expired: true,
          access_token: fakeJeton
        });
        spies.gestionnaireUtilisateur.getUser.and.resolveTo(utilisateur);
        let jeton!: string | null;

        service.obtenirJeton().then(resultat => jeton = resultat);
        tick();

        expect(jeton).toBeFalsy();
      }));
    });

    describe(`obtenirInfosJeton`, () => {
      let mockJeton: Jeton;

      beforeEach(() => {
        mockJeton = new MockJeton();
        spies.jwtHelper.decodeToken.and.returnValue(mockJeton);
      });

      it(`ne doit pas retourner de jeton SI l'utilisateur n'est pas connecté`, () => {
        const jeton = service.obtenirInfosJeton();

        expect(jeton).toBeFalsy();
        expect(spies.jwtHelper.decodeToken).not.toHaveBeenCalled();
      });

      it(`doit retourner un jeton SI l'utilisateur existe ET est connecté`, fakeAsync(() => {
        const mockUtilisateur = MockService(User);
        spies.gestionnaireUtilisateur.signinRedirectCallback.and.resolveTo(mockUtilisateur);

        service.completerConnexion();
        tick();
        const jetonRecu = service.obtenirInfosJeton();

        expect(jetonRecu).toBe(mockJeton);
        expect(service.Statut).toEqual(StatutAuthentification.Authentifie);
        expect(spies.jwtHelper.decodeToken).toHaveBeenCalled();
      }));
    });
  });
});

// Mocks et fixtures
class MockJeton extends Jeton {
  constructor(public testUUID: string = UUID()) {
    super();
  }
}

class FixtureInitialiserAuthentificationEntree implements InitialiserAuthentificationEntree {
  UrlSource = UUID();
  Oidc = {
    IdClient: UUID(),
    UriHoteRedirection: UUID(),
    ScopeAPI: UUID()
  };
}

class TestSpies {
  jwtHelper = createSpyFromClass(JwtHelperService);
  gestionnaireUtilisateur = createSpyFromClass(UserManager);
}
