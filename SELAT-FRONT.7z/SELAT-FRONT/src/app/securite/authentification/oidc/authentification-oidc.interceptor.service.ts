/* eslint-disable @typescript-eslint/no-unused-vars */
import { Inject, Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpRequest } from '@angular/common/http';
import { of, from, Observable } from 'rxjs';
import { concatAll } from 'rxjs/operators';

/////////////////////////////////////
// ToDo : Briser ces dépendances
/////////////////////////////////////
import { CONTEXTESERVICE, ContexteService } from 'src/app/securite/contexte/contexte.service';
import { JournalisationService } from 'src/app/journalisation.service';
/////////////////////////////////////
import { AuthentificationOidcService } from './authentification-oidc.service';
import { AuthentificationInterceptorService } from '../authentification.interceptor.service';
import { StatutAuthentification } from '../statut-authentification.enum';

@Injectable({ providedIn: 'root' })
export class AuthentificationOidcInterceptorService extends AuthentificationInterceptorService {
  private deleguerInterception!: (req: HttpRequest<never>, next: HttpHandler) => Observable<HttpEvent<unknown>>;

  constructor(private authentificationService: AuthentificationOidcService,
    @Inject(CONTEXTESERVICE) contexteService: ContexteService) {
    super(contexteService);
    this.authentificationService?.ChangementStatut$.subscribe(etat => {
      switch (etat) {
        case StatutAuthentification.NonAuthentifie: this.deleguerInterception = this.attenteCallback; break;
        case StatutAuthentification.Deconnecte: this.deleguerInterception = this.annulerAppel; break;
        default: this.deleguerInterception = this.intercepter;
      }
    });
  }

  private annulerAppel(req: HttpRequest<never>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    JournalisationService.tracer('Utilisateur déconnecté, on annule tous les appels');
    return of({}) as never;
  }

  private attenteCallback(req: HttpRequest<never>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    JournalisationService.tracer('Utilisateur en cours de connexion, on annule les appels qui ne sont pas vers les ressources locales');
    return !this.estInterceptable(req.url) ? next.handle(req) : of({}) as never;
  }

  private intercepter(req: HttpRequest<never>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    JournalisationService.tracer('Entré dans intercepteur. Url : ' + req.url);
    if (this.estInterceptable(req.url)) {
      JournalisationService.tracer('Appel interceptable.');
      return from(this.authentificationService.obtenirJeton().then(token => {
        JournalisationService.tracer('utilisateur authentifié, on ajoute le jeton en entête.');
        const bearer = `Bearer ${token}`;
        const authReq = req.clone({
          headers: req.headers.set('Authorization', bearer),
        });
        return next.handle(authReq);
      })).pipe(concatAll());
    } else {
      return next.handle(req);
    }
  }

  intercept(req: HttpRequest<never>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    return this.deleguerInterception(req, next);
  }
}
