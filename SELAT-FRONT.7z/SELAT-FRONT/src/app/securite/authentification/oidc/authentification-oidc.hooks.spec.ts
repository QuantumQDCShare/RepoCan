/*import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { Transition, TransitionService, UIRouter } from '@uirouter/core';
import { MockService, MockBuilder } from 'ng-mocks';
import { v4 as UUID } from 'uuid';
import { of } from 'rxjs';

import { JournalisationService, Niveau } from 'src/app/journalisation.service';
import { StatutAuthentification } from '../statut-authentification.enum';
import { AuthentificationOidcHooks } from './authentification-oidc.hooks';
import { AuthentificationOidcService } from './authentification-oidc.service';

type ConnectionOIDCEntree = { etatAccueil: string, etatErreurAuthentification: string, etatErreurTechnique: string };
type DeconnectionOIDCEntree = { etatDeconnexion: string };

describe(`Hooks: AuthentificationOidc`, () => {
  let spies: TestSpies;
  let transition: Transition;
  let serviceTransition: TransitionService;
  let statutTest: StatutAuthentification;

  const initialiserTransitionService = (): TransitionService => {
    return MockService(TransitionService, {
      onStart: spies.onStart.and.callFake((ignore: unknown, callback: (transition: Transition) => never) =>
        callback(transition)
      )
    });
  };

  const initialiserTransition = (): Transition => {
    return MockService(Transition, {
      router: MockService(UIRouter, { stateService: spies.stateService }),
      injector: jasmine.createSpy('injector').and.returnValue({
        get: jasmine.createSpy('get').and.callFake(classe => TestBed.inject(classe))
      })
    });
  };

  beforeEach(() => {
    statutTest = StatutAuthentification.NonAuthentifie;
    spies = new TestSpies();
    serviceTransition = initialiserTransitionService();
    transition = initialiserTransition();
    const ngModule = MockBuilder()
      .mock(AuthentificationOidcService, {
        get Statut(): StatutAuthentification { return statutTest; },
        completerConnexion: spies.completerConnexion,
        completerDeconnexion: spies.completerDeconnexion
      })
      .mock(JournalisationService, { inscrire: spies.journaliser })
      .build();
    TestBed.configureTestingModule(ngModule);
  });

  it(`doit pouvoir s'accrocher au cycle de vie 'OnStart' du service de transition`, () => {
    spies.onStart.and.callFake(() => { });
    const params = { etatAccueil: '', etatErreurAuthentification: '', etatErreurTechnique: '' };

    AuthentificationOidcHooks.OnStart.connectionOIDC(serviceTransition, params);

    expect(spies.onStart).toHaveBeenCalled();
  });

  describe(`OnStart`, () => {
    const hooks = AuthentificationOidcHooks.OnStart;

    describe(`connectionOIDC`, () => {
      let params: ConnectionOIDCEntree;

      beforeEach(() => {
        params = {
          etatAccueil: UUID(),
          etatErreurAuthentification: UUID(),
          etatErreurTechnique: UUID()
        };
      });

      it(`doit s'accrocher au cycle de vie 'onStart' du service de transition sur le critère 'connexionOIDC'`, () => {
        let resultatCritereTo = false;
        const etatCritere = { data: { connexionOIDC: true } };
        spies.onStart.and.callFake((critere) => resultatCritereTo = critere.to(etatCritere));

        hooks.connectionOIDC(serviceTransition, params);

        expect(resultatCritereTo).toBeTrue();
      });

      it(`ne doit pas s'accrocher au cycle de vie 'onStart' du service de transition SI le critère 'connexionOIDC' est absent`, () => {
        let resultatCritereTo = false;
        const etatCritere = { data: { [UUID()]: true } };
        spies.onStart.and.callFake((critere) => resultatCritereTo = critere.to(etatCritere));

        hooks.connectionOIDC(serviceTransition, params);

        expect(resultatCritereTo).toBeFalsy();
      });

      it(`doit rediriger vers la page d'accueil SI aucune erreur n'est retournée`, fakeAsync(() => {
        spies.completerConnexion.and.resolveTo({ test: UUID() });

        hooks.connectionOIDC(serviceTransition, params);
        tick();

        expect(spies.stateService.target).toHaveBeenCalledWith(
          params.etatAccueil,
          undefined,
          { location: 'replace' }
        );
      }));

      it(`doit rediriger vers l'état de routage 'pageErreurAuthentification' avec le code d'erreur SI une erreur est retournée ET que le statut de connexion est 'ErreurAuthentification'`, fakeAsync(() => {
        const erreur = UUID();
        spies.completerConnexion.and.resolveTo(new Error(erreur));
        statutTest = StatutAuthentification.ErreurAuthentification;

        hooks.connectionOIDC(serviceTransition, params);
        tick();

        expect(spies.stateService.target).toHaveBeenCalledWith(
          params.etatErreurAuthentification,
          { code: erreur },
          { location: 'replace', reload: false }
        );
      }));

      it(`doit rediriger vers l'état de routage 'pageErreurTechnique' avec le code d'erreur SI une erreur est retournée ET que le statut de connexion est 'ErreurTechnique'`, fakeAsync(() => {
        const erreur = UUID();
        spies.completerConnexion.and.resolveTo(new Error(erreur));
        statutTest = StatutAuthentification.ErreurTechnique;

        hooks.connectionOIDC(serviceTransition, params);
        tick();

        expect(spies.stateService.target).toHaveBeenCalledWith(
          params.etatErreurTechnique,
          { code: erreur },
          { location: 'replace', reload: false }
        );
      }));

      it(`doit journaliser l'erreur SI une erreur est retournée`, fakeAsync(() => {
        const erreur = new Error(UUID());
        spies.completerConnexion.and.resolveTo(erreur);

        hooks.connectionOIDC(serviceTransition, params);
        tick();

        expect(spies.journaliser).toHaveBeenCalledWith(erreur, Niveau.ERROR);
      }));

      it(`doit lancer une erreur SI la promesse d'authentification ne retourne rien`, fakeAsync(() => {
        spies.completerConnexion.and.returnValue(of(undefined));

        const trapErreur = () => {
          hooks.connectionOIDC(serviceTransition, params);
          tick();
        };

        expect(trapErreur).toThrow();
      }));
    });

    describe(`deconnexionOIDC`, () => {
      let params: DeconnectionOIDCEntree;

      beforeEach(() => {
        params = { etatDeconnexion: UUID() };
      });

      it(`doit s'accrocher au cycle de vie 'onStart' du service de transition sur le critère deconnexionOIDC`, () => {
        // Arranger
        let resultatCritereTo = false;
        const etatCritere = { data: { deconnexionOIDC: true } };
        spies.onStart.and.callFake((critere) => resultatCritereTo = critere.to(etatCritere));

        // Agir
        hooks.deconnectionOIDC(serviceTransition, params);

        // Assertion
        expect(resultatCritereTo).toBeTrue();
      });

      it(`ne doit pas s'accrocher au cycle de vie 'onStart' du service de transition SI le critère deconnexionOIDC est absent`, () => {
        let resultatCritereTo = false;
        const etatCritere = { data: { [UUID()]: true } };
        spies.onStart.and.callFake((critere) => resultatCritereTo = critere.to(etatCritere));

        hooks.deconnectionOIDC(serviceTransition, params);

        expect(resultatCritereTo).toBeFalsy();
      });

      it(`doit rediriger vers la page de déconnexion`, () => {
        hooks.deconnectionOIDC(serviceTransition, params);

        expect(spies.stateService.target).toHaveBeenCalledWith(
          params.etatDeconnexion,
          undefined,
          { location: 'replace' }
        );
      });
    });
  });
});

// Mocks et Fixtures
class TestSpies {
  stateService = jasmine.createSpyObj('stateService', ['target']);
  verifierRolesAcces = jasmine.createSpy('verifierRolesAcces').and.returnValue({ Autorise: true });
  onStart = jasmine.createSpy('onStart');
  completerConnexion = jasmine.createSpy('completerConnexion');
  completerDeconnexion = jasmine.createSpy('completerDeconnexion').and.returnValue({
    then: jasmine.createSpy('then').and.callFake(x => x())
  });
  journaliser = jasmine.createSpy('journaliser');
}
*/