import { User } from 'oidc-client-ts';
import { JournalisationService, Niveau } from 'src/app/journalisation.service';
import { AuthentificationOidcService } from './authentification-oidc.service';
import { Router } from '@angular/router';

type ConnectionOIDCEntree = { 
  etatPrincipal: string, 
  etatErreurAuthentification: string, 
  etatErreurTechnique: string, 
  etatIntrouvable: string 
};
type DeconnectionOIDCEntree = { etatDeconnexion: string };

export class AuthentificationOidcHooks {

  static async connectionOIDC(
    etats: ConnectionOIDCEntree, 
    auth: AuthentificationOidcService, 
    journal: JournalisationService, 
    router: Router
  ): Promise<void> {
    console.log('Début ConnectionOIDC');
    try {
      const resultat: User | Error = await auth.completerConnexion();
      
      if (resultat instanceof Error && resultat.message) {
        const messageErreur = resultat.message;
        console.log('Erreur durant la connexion OIDC:', resultat);
        journal.inscrire(resultat, Niveau.ERROR);
        const etatErreur = auth.Statut == 3 ? 
          etats.etatErreurTechnique : auth.Statut == 5 ? 
            etats.etatIntrouvable : etats.etatErreurAuthentification;
          
        if(etatErreur == etats.etatIntrouvable || etatErreur == etats.etatErreurAuthentification)
          router.navigate([etatErreur]);
        else
          router.navigate([etatErreur], { queryParams: { code: messageErreur } });
      } else {
        console.log('Connexion OIDC réussie, redirection vers:', etats.etatPrincipal);
        router.navigate([etats.etatPrincipal]);
      }
    } catch (error) {
      console.log('Erreur dans le bloc catch:', error);
      journal.inscrire(error, Niveau.ERROR);
      router.navigate([etats.etatErreurTechnique], { queryParams: { code: error } });
    }
  }

  static async deconnectionOIDC(etats: DeconnectionOIDCEntree, auth: AuthentificationOidcService, router: Router): Promise<void> {
    console.log('Début DeconnectionOIDC');
    try {
      await auth.completerDeconnexion();
      console.log('Déconnexion OIDC réussie, redirection vers:', etats.etatDeconnexion);
      router.navigate([etats.etatDeconnexion]);
    } catch (error) {
      console.log('Erreur durant la déconnexion OIDC:', error);
      // Gérer l'erreur de déconnexion si nécessaire
    }
  }
}
