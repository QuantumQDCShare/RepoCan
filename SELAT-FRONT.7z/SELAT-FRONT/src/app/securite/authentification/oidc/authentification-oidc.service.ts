import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, from, of } from 'rxjs';
import { UserManager, User, SignoutResponse } from 'oidc-client-ts';
import { JwtConfig, JwtHelperService } from '@auth0/angular-jwt';
import { Constantes } from '../constantes';
import { AuthentificationService } from '../interfaces/authentification.service';
import { StatutAuthentification } from '../statut-authentification.enum';
import { InitialiserAuthentificationEntree } from '../interfaces/initialiser-authentification.entree';
import { Jeton } from '../modeles/jeton';

@Injectable()
export class AuthentificationOidcService implements AuthentificationService {
  static get UrlNavigateur(): string { return window.location.pathname; }
  private etat = new BehaviorSubject<StatutAuthentification>(StatutAuthentification.NonAuthentifie);
  private gestionnaireUtilisateur!: UserManager;
  private utilisateur: User | null | undefined;
  public get Statut(): StatutAuthentification { return this.etat.value; }
  public get ChangementStatut$(): Observable<StatutAuthentification> { return this.etat.asObservable(); }
  private jwtHelper: JwtHelperService;

  constructor() {
    const configurationJWT: JwtConfig = {
      tokenGetter: () => this.utilisateur ? this.utilisateur.access_token : ''
    };
    this.jwtHelper = new JwtHelperService(configurationJWT);
  }

  initialiser(params: InitialiserAuthentificationEntree): Observable<unknown> {
    if (!this.gestionnaireUtilisateur && !!params.Oidc) {
      console.log('test : ', params.Oidc.IdClient);
      const parametres = {
        authority: params.UrlSource,
        client_id: params.Oidc.IdClient,
        redirect_uri: `${params.Oidc.UriHoteRedirection}/${Constantes.OIDC.URI_CONNEXION}`,
        post_logout_redirect_uri: `${params.Oidc.UriHoteRedirection}/${Constantes.OIDC.URI_DECONNEXION}`,
        scope: `${params.Oidc.ScopeAPI}`,
        response_type: Constantes.OIDC.RESPONSE_TYPE,
        loadUserInfo: false
      };
      this.gestionnaireUtilisateur = new UserManager(parametres);
    }
    return this.traiterEtatConnexion();
  }

  private traiterEtatConnexion(): Observable<unknown> {
    //gérer l'URL invalide
    let url: string = '/';
    if (AuthentificationOidcService.UrlNavigateur == '/' || AuthentificationOidcService.UrlNavigateur == Constantes.OIDC.ACCUEIL) {
      url = Constantes.OIDC.ACCUEIL;
    }
    return url === Constantes.OIDC.ACCUEIL ? this.connecter() : of({});
  }

  connecter(): Observable<unknown> {
    return from(this.gestionnaireUtilisateur.signinRedirect().catch((error) => {
      console.error('Erreur lors de la redirection pour l’authentification:', error);
    }));
  }

  estConnecte(): Promise<boolean> {
    return this.gestionnaireUtilisateur.getUser().then((utilisateur: User | null) => {
      const utilisateurCourant = !!utilisateur && !utilisateur.expired;

      if (this.utilisateur !== utilisateur) {
        this.etat.next(utilisateurCourant ? StatutAuthentification.Authentifie : StatutAuthentification.NonAuthentifie);
      }
      this.utilisateur = utilisateur;
      localStorage.setItem('utilisateurCourant',JSON.stringify(utilisateur));
      return utilisateurCourant;
    });
  }

  public get utilisateurCourant(): User {
    return this.utilisateur;
  }

  completerConnexion(): Promise<User | Error> {
    return this.gestionnaireUtilisateur.signinRedirectCallback().then(
      (utilisateur: User) => {
        console.log('user : ', utilisateur);
        this.utilisateur = utilisateur;
        this.etat.next(!!utilisateur && !utilisateur.expired ? StatutAuthentification.Authentifie : StatutAuthentification.NonAuthentifie);
        return utilisateur;
      },
      (erreur: Error) => {
        console.log('Erreur lors du callback d’authentification : ', erreur);
        if (this.estErreurAuthentification(erreur)) {
          this.etat.next(StatutAuthentification.ErreurAuthentification);
        } else {
          if (AuthentificationOidcService.UrlNavigateur == '/pageErreurTechnique') {
            this.etat.next(StatutAuthentification.ErreurTechnique);
          } else {
            this.etat.next(StatutAuthentification.PageIntrouvable);
          }
        }
        return erreur;
      }
    );
  }

  private estErreurAuthentification(erreur: Error): boolean {
    // ToDo: Trouver un meilleur discriminant pour ne pas dépendre du fabricant
    const serial = JSON.stringify(erreur, Object.getOwnPropertyNames(erreur)).toUpperCase();
    return Constantes.OIDC.CODES_ERREUR_AUTHENTIFICATION.some(
      code => serial.includes(code.toUpperCase())
    );
  }

  deconnecter(): Observable<unknown> {
    localStorage.removeItem('utilisateurCourant');
    return from(this.gestionnaireUtilisateur.signoutRedirect());
  }

  completerDeconnexion(): Promise<SignoutResponse> {
    this.utilisateur = null;
    this.etat.next(StatutAuthentification.Deconnecte);
    return this.gestionnaireUtilisateur.signoutRedirectCallback();
  }

  obtenirJeton(): Promise<string | null> {
    return this.gestionnaireUtilisateur.getUser().then((user: User | null) => {
      if (!!user && !user.expired) {
        return user.access_token;
      } else {
        return null;
      }
    });
  }

  obtenirInfosJeton(): Jeton | undefined {
    if (this.utilisateur && this.Statut === StatutAuthentification.Authentifie) {
      const jeton = this.jwtHelper.decodeToken<Jeton>();
      return jeton as Jeton;
    }
    return undefined;
  }
}
