/* eslint-disable @typescript-eslint/no-explicit-any */
import { fakeAsync, inject, TestBed, tick } from '@angular/core/testing';
import { Injector } from '@angular/core';
import { MockBuilder } from 'ng-mocks';
import { v4 as UUID } from 'uuid';

import { AuthentificationModule } from '.';
import { Jeton } from './modeles/jeton';
import { AuthentificationFacadeService } from './authentification-facade.service';
import { InitialiserAuthentificationEntree } from './interfaces/initialiser-authentification.entree';
import { AuthentificationService } from './interfaces/authentification.service';
import { TypeAuthentification } from './type-authentification.enum';
import { AuthentificationOidcService } from './oidc/authentification-oidc.service';
import { StatutAuthentification } from './statut-authentification.enum';

// Tests nécessitant un second rehaussement
describe(`Service: AuthentificationFacade`, () => {
  let service: AuthentificationFacadeService;
  let mockAuthentification: AuthentificationService;
  let spies: TestSpies;
  let injector: Injector;

  beforeEach(() => {
    spies = new TestSpies();
    const ngModule = MockBuilder(AuthentificationFacadeService, AuthentificationModule)
      .provide({ provide: TypeAuthentification, useValue: TypeAuthentification.Oidc })
      .mock(AuthentificationOidcService, spies.authentificationOidc as any)
      .build();
    TestBed.configureTestingModule(ngModule);
    mockAuthentification = TestBed.inject(AuthentificationOidcService);
    service = TestBed.inject(AuthentificationFacadeService);
    injector = TestBed.inject(Injector);
  });

  describe(`Initialisation`, () => {
    it(`doit être créé`, () => {
      expect(service).toBeTruthy();
    });

    it(`doit écouter les changements d'état de connexion SI le service d'authentification est initialisé`, () => {
      expect(spies.authentificationOidc.ChangementStatut$.subscribe).toHaveBeenCalled();
    });

    it(`ne doit pas écouter les changements d'état de connexion SI le service d'authentification n'est pas initialisé`, () => {
      spies.authentificationOidc.ChangementStatut$.subscribe.calls.reset();

      service = new AuthentificationFacadeService(injector, TypeAuthentification.Differee);

      expect(spies.authentificationOidc.ChangementStatut$.subscribe).not.toHaveBeenCalled();
    });

    it(`doit retourner l'état 'ErreurTechnique' SI le service d'authentification n'est pas initialisé`, () => {
      service = new AuthentificationFacadeService(injector, TypeAuthentification.Differee);
      const etat = service.Etat;

      expect(etat).toEqual(StatutAuthentification.ErreurTechnique);
    });

    it(`ne doit pas initialiser le service d'authentification à la construction SI le type d'authentification est 'Differee'`, () => {
      const spy = { injector: spyOn(injector, 'get').and.callThrough() };

      service = new AuthentificationFacadeService(injector, TypeAuthentification.Differee);

      expect(spy.injector).not.toHaveBeenCalled();
    });

    it(`doit adapter le service à 'Oidc' SI le type d'authentification est 'Oidc'`, () => {
      const spy = { injector: spyOn(injector, 'get').and.callThrough() };

      service = new AuthentificationFacadeService(injector, TypeAuthentification.Oidc);
      const resultat = spy.injector.calls.mostRecent()?.args[0]?.name;

      expect(spy.injector).toHaveBeenCalled();
      expect(resultat).toEqual(AuthentificationOidcService.name);
    });
  });

  describe(`Fonctions`, () => {
    describe(`etat`, () => {
      let spyMockAuthentification: any;

      beforeEach(() => {
        spyMockAuthentification = spyOnProperty(mockAuthentification, 'Statut');
      });

      it(`doit retourner l'état obtenu du service d'authentification`, () => {
        service.Etat;

        expect(spyMockAuthentification).toHaveBeenCalled();
      });
    });

    describe(`initialiser`, () => {
      let spyMockAuthentificationOidc: jasmine.Spy;
      let spyInjector: jasmine.Spy;

      beforeEach(inject([AuthentificationOidcService], (oidc: AuthentificationOidcService) => {
        spyMockAuthentificationOidc = spyOn(oidc, 'initialiser').and.returnValue({ subscribe: jasmine.createSpy() } as never);
        spyInjector = spyOn(injector, 'get').and.callThrough();
      }));

      describe(`Mode non 'Differee'`, () => {
        it(`doit appeler l'initialisation du service d'authentification avec l'url passé`, () => {
          const url: InitialiserAuthentificationEntree = { UrlSource: UUID() };

          service.initialiserAuthentification(url);

          expect(spyMockAuthentificationOidc).toHaveBeenCalledWith(url);
          expect(spyInjector).not.toHaveBeenCalled();
        });
      });

      describe(`Mode 'Differee'`, () => {
        let paramEntree: InitialiserAuthentificationEntree;

        beforeEach(() => {
          paramEntree = { UrlSource: UUID() };
          spies.authentificationOidc.ChangementStatut$.subscribe.calls.reset();
          service = new AuthentificationFacadeService(injector, TypeAuthentification.Differee);
        });

        it(`doit intialiser le mode 'Oidc' SI les paramètres de ce dernier sont fournis`, () => {
          paramEntree.Oidc = { IdClient: UUID(), UriHoteRedirection: UUID(), ScopeAPI: UUID() };

          service.initialiserAuthentification(paramEntree).subscribe();
          const resultat = spyInjector.calls.mostRecent()?.args[0]?.name;

          expect(spyInjector).toHaveBeenCalled();
          expect(resultat).toEqual(AuthentificationOidcService.name);
        });

        it(`doit émettre l'état de connexion 'ErreurTechnique' sans injecter de service d'authentification SI aucun paramètres supplémentaires ne sont fournis`, fakeAsync(() => {
          let etatRecu!: StatutAuthentification;

          service.ChangementEtat$.subscribe(etat => etatRecu = etat);
          service.initialiserAuthentification(paramEntree).subscribe();
          tick();

          expect(spyInjector).not.toHaveBeenCalled();
          expect(etatRecu).toEqual(StatutAuthentification.ErreurTechnique);
        }));

        it(`ne doit pas souscrire aux changements d'état du service d'authentification SI ce dernier n'est pas initialisé`, fakeAsync(() => {
          service.initialiserAuthentification(paramEntree).subscribe();
          tick();

          expect(spies.authentificationOidc.ChangementStatut$.subscribe).not.toHaveBeenCalled();
        }));

        it(`doit souscrire aux changements d'état du service d'authentification SI ce dernier est initialisé`, fakeAsync(() => {
          paramEntree.Oidc = { IdClient: UUID(), UriHoteRedirection: UUID(), ScopeAPI: UUID() };

          service.initialiserAuthentification(paramEntree).subscribe();
          tick();

          expect(spies.authentificationOidc.ChangementStatut$.subscribe).toHaveBeenCalled();
        }));
      });
    });

    describe(`déconnexion`, () => {
      it(`doit appeler le service d'authentification pour effectuer la déconnexion SI ce dernier est initialisé`, () => {
        const spyMockAuth = spyOn(mockAuthentification, 'deconnecter').and.resolveTo();

        service.deconnecter();

        expect(spyMockAuth).toHaveBeenCalled();
      });

      it(`doit ne rien faire SI le service d'authentification n'est pas initialisé`, () => {
        const spyMockAuth = spyOn(mockAuthentification, 'deconnecter').and.resolveTo();
        service = new AuthentificationFacadeService(injector, TypeAuthentification.Differee);

        service.deconnecter();

        expect(spyMockAuth).not.toHaveBeenCalled();
      });
    });

    describe(`recupererCopieJeton`, () => {
      let jeton: Jeton | undefined;
      let fakeJeton: Jeton | undefined;
      let spyMockJeton: any;

      beforeEach(() => {
        jeton = undefined;
        fakeJeton = undefined;
        spyMockJeton = spyOn(mockAuthentification, 'obtenirInfosJeton').and.callFake(() => {
          fakeJeton = new MockJeton(UUID());
          return fakeJeton;
        });
      });

      it(`doit retourner un jeton provenant du service de jeton`, () => {
        jeton = service.recupererCopieJeton();

        expect(spyMockJeton).toHaveBeenCalled();
        expect(jeton).toBeDefined();
      });

      it(`doit retourner un jeton dont les modifications n'affectent pas l'original`, () => {
        const nouveauUpn = UUID();
        let jetonID: string | undefined;

        jeton = service.recupererCopieJeton();
        if (jeton) {
          jeton.unique_name = nouveauUpn;
          jetonID = (jeton as MockJeton).testUUID;
        }
        const fakeJetonID = (fakeJeton as MockJeton).testUUID;

        expect(jeton).toBeDefined();
        expect(fakeJetonID).toBeTruthy();
        expect(fakeJeton).not.toBe(jeton);
        expect(jetonID).toEqual(fakeJetonID);
        expect(fakeJeton?.unique_name).not.toEqual(jeton?.unique_name);
      });

      it(`doit retourner 'undefined' SI le service d'authentification n'est pas initialisé`, () => {
        service = new AuthentificationFacadeService(injector, TypeAuthentification.Differee);

        jeton = service.recupererCopieJeton();

        expect(jeton).not.toBeDefined();
      });
    });
  });
});

// Mocks et fixtures
class TestSpies {
  authentificationOidc: {
    ChangementStatut$: { subscribe: jasmine.Spy },
    initialiser: { subscribe: jasmine.Spy },
  } = {
      ChangementStatut$: this.creerSpyObjetSubscribe('ChangementStatut$'),
      initialiser: this.creerSpyObjetSubscribe('initialiser')
    };

  private creerSpyObjetSubscribe(libelle = ''): any {
    return jasmine.createSpyObj(libelle, ['subscribe'], {
      subscribe: jasmine.createSpy('subscribe')
    });
  }
}

class MockJeton extends Jeton {
  constructor(public testUUID?: string) {
    super();
    this.testUUID = testUUID;
    this.aud = UUID();
    this.iss = UUID();
    this.iat = UUID();
    this.nbf = UUID();
    this.exp = UUID();
    this.unique_name = UUID();
    this.anchor = UUID();
    this.role = [UUID()];
    this.apptype = UUID();
    this.appid = UUID();
    this.authmethod = UUID();
    this.auth_time = UUID();
    this.ver = UUID();
    this.scp = UUID();
  }
}
