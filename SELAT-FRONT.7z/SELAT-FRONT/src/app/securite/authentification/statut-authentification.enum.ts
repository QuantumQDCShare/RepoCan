export enum StatutAuthentification {
  NonAuthentifie,
  Authentifie,
  ErreurAuthentification,
  ErreurTechnique,
  Deconnecte,
  PageIntrouvable
}
