class Oidc {
  static readonly ACCUEIL = '/accueil';
  static readonly INTROUVABLE = '/PageIntrouvable';
  static readonly RESPONSE_TYPE = 'code';
  static readonly URI_CONNEXION = 'oidc-connexion';
  static readonly URI_DECONNEXION = 'oidc-deconnexion';
  static CODES_ERREUR_AUTHENTIFICATION: ReadonlyArray<string> = ['MSIS7068', 'MSIS7121', 'ID4070', 'access_denied'];
}

export class Constantes {
  static readonly OIDC = Oidc;
}
