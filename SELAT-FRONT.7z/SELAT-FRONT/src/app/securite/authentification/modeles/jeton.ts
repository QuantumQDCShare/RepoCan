export class Jeton {
  aud = '';
  iss = '';
  iat = '';
  nbf = '';
  exp = '';
  unique_name = '';
  anchor = '';
  role: string[] | string = [];
  apptype = '';
  appid = '';
  authmethod = '';
  auth_time = '';
  ver = '';
  scp = '';
}
