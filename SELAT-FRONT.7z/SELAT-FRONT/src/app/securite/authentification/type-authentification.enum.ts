export enum TypeAuthentification {
  Oidc = 'OIDC',
  Differee = 'Differee'
}
