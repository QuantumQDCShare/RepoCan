import { TestBed } from '@angular/core/testing';
import { MockBuilder } from 'ng-mocks';
import { v4 as UUID } from 'uuid';

import { AuthentificationFacadeService, Jeton } from 'src/app/securite/authentification';
import { CodeErreur } from './code-erreur.enum';
import { Constantes } from './constantes';
import { AutorisationService } from './autorisation.service';

describe('Service: Autorisation', () => {
  let service: AutorisationService;
  let authentification: AuthentificationFacadeService;

  beforeEach(() => {
    const ngModule = MockBuilder(AutorisationService)
      .mock(AuthentificationFacadeService)
      .build();
    TestBed.configureTestingModule(ngModule);
    service = TestBed.inject(AutorisationService);
    authentification = TestBed.inject(AuthentificationFacadeService);
  });

  describe(`Initialisation`, () => {
    it(`doit être créé`, () => {
      expect(service).toBeTruthy();
    });
  });

  describe(`Propriété: RolesAutorises`, () => {
    it(`doit retourner une liste de rôles AIS`, () => {
      const rolesAutorises = AutorisationService.RolesAutorises;

      expect(rolesAutorises).toBeDefined();
    });

    it(`doit retourner la liste de rôles AIS contenus dans la constante ROLES_AUTORISES`, () => {
      const rolesAutorises = AutorisationService.RolesAutorises;

      expect(rolesAutorises).toEqual(Constantes.ROLES_AUTORISES);
    });
  });

  describe(`Fonction: verifierRoles`, () => {
    let fixtureRoles: string[];
    let mockJeton: Jeton;

    beforeEach(() => {
      mockJeton = new MockJeton();
      fixtureRoles = [UUID(), UUID(), UUID()];
      spyOnProperty(AutorisationService, 'RolesAutorises').and.returnValue(fixtureRoles);
      spyOn(authentification, 'recupererCopieJeton').and.returnValue(mockJeton);
    });

    describe(`Rôles AIS autorisés`, () => {
      describe(`Lorsque le délégué 'surRoleRefuse' est fourni en paramètre`, () => {
        it(`ne doit pas invoquer le délégué 'surRoleRefuse' SI le rôle est autorisé`, () => {
          mockJeton.role = [fixtureRoles[0]];
          const spysurRoleRefuse = jasmine.createSpy('surRoleRefuse');

          service.verifierRoles({
            jeton: mockJeton,
            surRoleRefuse: spysurRoleRefuse
          });

          expect(spysurRoleRefuse).not.toHaveBeenCalled();
        });
      });

      describe(`Lorsque le jeton contient une liste de rôle`, () => {
        it(`doit autoriser l'accès SI le rôle AIS du jeton est trouvé dans la liste de rôles requis`, () => {
          mockJeton.role = [fixtureRoles[0]];

          const resultat = service.verifierRoles({ jeton: mockJeton });

          expect(resultat).toBeTrue();
        });

        it(`doit autoriser l'accès SI un des rôles AIS du jeton est trouvé dans la liste de rôles requis`, () => {
          mockJeton.role = [UUID(), UUID(), UUID(), fixtureRoles[0]];

          const resultat = service.verifierRoles({ jeton: mockJeton });

          expect(resultat).toBeTrue();
        });

        it(`doit autoriser l'accès SI tous les rôles AIS du jeton sont trouvés dans la liste de rôles requis`, () => {
          mockJeton.role = [...fixtureRoles];

          const resultat = service.verifierRoles({ jeton: mockJeton });

          expect(resultat).toBeTrue();
        });
      });

      describe(`Lorsque le jeton contient une chaîne de rôles`, () => {
        it(`doit autoriser l'accès SI le rôle AIS du jeton est trouvé dans la chaîne de rôles requis`, () => {
          mockJeton.role = fixtureRoles[0];

          const resultat = service.verifierRoles({ jeton: mockJeton });

          expect(resultat).toBeTrue();
        });

        it(`doit autoriser l'accès SI un des rôles AIS du jeton est trouvé dans la chaîne de rôles requis`, () => {
          mockJeton.role = [UUID(), UUID(), UUID(), fixtureRoles[0]].join(', ');

          const resultat = service.verifierRoles({ jeton: mockJeton });

          expect(resultat).toBeTrue();
        });

        it(`doit autoriser l'accès SI tous les rôles AIS du jeton sont trouvés dans la chaîne de rôles requis`, () => {
          mockJeton.role = [...fixtureRoles].join(', ');

          const resultat = service.verifierRoles({ jeton: mockJeton });

          expect(resultat).toBeTrue();
        });
      });
    });

    describe(`Rôles AIS refusés`, () => {
      describe(`Lorsque le délégué 'surRoleRefuse' est fourni en paramètre`, () => {
        let spySurRoleRefuse: jasmine.Spy;

        beforeEach(() => spySurRoleRefuse = jasmine.createSpy('surRoleRefuse'));

        it(`doit invoquer le délégué 'surRoleRefuse' AVEC le code d'HLI5-4002 ainsi que ses paramètres SI le rôle est refusé`, () => {
          mockJeton.role = [UUID()];
          const raisonRejetAttendu = {
            code: CodeErreur.AIS_4002,
            params: {
              Identifiant: mockJeton.unique_name
            }
          };

          service.verifierRoles({
            jeton: mockJeton,
            surRoleRefuse: spySurRoleRefuse
          });

          expect(spySurRoleRefuse).toHaveBeenCalledWith(raisonRejetAttendu);
        });

        it(`doit invoquer le délégué 'surRoleRefuse' AVEC le message code d'erreur HLI5-4001 SI le jeton n'a pas de nom unique`, () => {
          mockJeton.unique_name = '';
          const raisonRejetAttendu = { code: CodeErreur.AIS_4001 };

          service.verifierRoles({
            jeton: mockJeton,
            surRoleRefuse: spySurRoleRefuse
          });

          expect(spySurRoleRefuse).toHaveBeenCalledWith(raisonRejetAttendu);
        });

        it(`doit invoquer le délégué 'surRoleRefuse' AVEC le message code d'erreur HLI5-4001 SI le jeton est inexistant`, () => {
          mockJeton.role = [fixtureRoles[0]];
          const raisonRejetAttendu = { code: CodeErreur.AIS_4001 };

          service.verifierRoles({
            jeton: undefined,
            surRoleRefuse: spySurRoleRefuse
          });

          expect(spySurRoleRefuse).toHaveBeenCalledWith(raisonRejetAttendu);
        });
      });

      describe(`Lorsque le jeton contient une liste de rôles`, () => {
        it(`doit refuser l'accès SI le jeton ne contient aucun rôle AIS`, () => {
          mockJeton.role = [];

          const resultat = service.verifierRoles({ jeton: mockJeton });

          expect(resultat).toBeFalse();
        });

        it(`doit refuser l'accès SI le rôle AIS du jeton n'est pas trouvé dans la liste de rôles requis`, () => {
          mockJeton.role = [UUID()];

          const resultat = service.verifierRoles({ jeton: mockJeton });

          expect(resultat).toBeFalse();
        });

        it(`doit refuser l'accès SI aucun des rôles AIS du jeton n'est trouvé dans la liste de rôles requis`, () => {
          mockJeton.role = [UUID(), UUID(), UUID()];

          const resultat = service.verifierRoles({ jeton: mockJeton });

          expect(resultat).toBeFalse();
        });
      });

      describe(`Lorsque le jeton contient une chaîne de rôles`, () => {
        it(`doit refuser l'accès SI le jeton ne contient aucun rôle AIS`, () => {
          mockJeton.role = '';

          const resultat = service.verifierRoles({ jeton: mockJeton });

          expect(resultat).toBeFalse();
        });

        it(`doit refuser l'accès SI le rôle AIS du jeton n'est pas trouvé dans la chaîne de rôles requis`, () => {
          mockJeton.role = UUID();

          const resultat = service.verifierRoles({ jeton: mockJeton });

          expect(resultat).toBeFalse();
        });

        it(`doit refuser l'accès SI aucun des rôles AIS du jeton n'est trouvé dans la chaîne de rôles requis`, () => {
          mockJeton.role = [UUID(), UUID(), UUID()].join(', ');

          const resultat = service.verifierRoles({ jeton: mockJeton });

          expect(resultat).toBeFalse();
        });
      });
    });
  });
});

// Mock et Fixtures
class MockJeton extends Jeton {
  testID = UUID();

  constructor() {
    super();
    this.unique_name = UUID();
    this.role = [];
  }
}
