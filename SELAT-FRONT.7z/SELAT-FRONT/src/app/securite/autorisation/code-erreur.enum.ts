export enum CodeErreur {
  AIS_4001 = 'ERREURS.HLI5-4001',
  AIS_4002 = 'ERREURS.HLI5-4002'
}
