import { Jeton } from 'src/app/securite/authentification';

export interface VerifierRolesEntree {
  jeton: Jeton | undefined;
  surRoleRefuse?: (raisonRefus: { code: string, params?: object }) => void;
}
