export class Constantes {
  static ROLES_AUTORISES: ReadonlyArray<string> = [
    'AIS_Pilotage_Consultation',
    'AIS_Pilotage_MiseAJour'
  ];
}
