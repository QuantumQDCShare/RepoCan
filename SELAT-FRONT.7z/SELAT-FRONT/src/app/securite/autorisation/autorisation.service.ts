import { Injectable } from '@angular/core';

// ToDo: Briser cette dépendance?
import { JournalisationService } from 'src/app/journalisation.service';
import { Jeton } from 'src/app/securite/authentification';
import { CodeErreur } from './code-erreur.enum';
import { Constantes } from './constantes';
import { VerifierRolesEntree } from './interfaces/verifier-roles.entree';

@Injectable({ providedIn: 'root' })
export class AutorisationService {
  static get RolesAutorises(): ReadonlyArray<string> { return Constantes.ROLES_AUTORISES; }

  constructor(private journal: JournalisationService) { }

  private static comparerRolesAutorises(jeton: Jeton): boolean {
    const roles: string[] = typeof (jeton.role) === 'string' ? jeton.role.split(',') : jeton.role;

    return roles?.some(role => AutorisationService.RolesAutorises
      .map(valeur => valeur.toUpperCase())
      .includes(role.trim().toUpperCase())
    );
  }

  private static obtenirParametresErreur4002(jeton: Jeton): object {
    return {
      Identifiant: jeton.unique_name
    };
  }

  verifierRoles(entree: VerifierRolesEntree): boolean {
    const jeton = entree.jeton;
    const refuser = entree.surRoleRefuse ? entree.surRoleRefuse : () => { };
    let autorise = false;

    if (!!jeton?.unique_name) {
      autorise = AutorisationService.comparerRolesAutorises(jeton);
      if (!autorise) {
        refuser({ code: CodeErreur.AIS_4002, params: AutorisationService.obtenirParametresErreur4002(jeton) });
      }
    } else {
      refuser({ code: CodeErreur.AIS_4001 });
    }
    this.journal.inscrire(`${this.verifierRoles.name} : ${autorise ? 'Aurorisé' : 'Refusé'}`);
    return autorise;
  }
}
