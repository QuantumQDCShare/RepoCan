/*import { TestBed } from '@angular/core/testing';

import { CONTEXTESERVICE, ContexteService } from './contexte.service';

describe('ContexteService', () => {
  let service: ContexteService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CONTEXTESERVICE);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});*/
