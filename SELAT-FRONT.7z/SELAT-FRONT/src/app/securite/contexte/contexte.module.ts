import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { lastValueFrom } from 'rxjs';

import { AuthentificationModule, AuthentificationFacadeService } from 'src/app/securite/authentification';
import { ContexteImplService } from './contexte.impl.service';
import { CONTEXTESERVICE, ContexteService } from './contexte.service';
import { InitialiserContexteEntree } from './initialiser-contexte.entree';

let contexteinstance: ContexteImplService;

export function contexteFactory(http: HttpClient, auth: AuthentificationFacadeService): ContexteImplService {
  if (!contexteinstance) {
    contexteinstance = new ContexteImplService(http, auth);
  }
  return contexteinstance;
}

@NgModule({
  imports: [
    CommonModule,
    HttpClientModule,
    AuthentificationModule
  ],
  providers: [
    { provide: CONTEXTESERVICE, deps: [HttpClient, AuthentificationFacadeService], useFactory: contexteFactory }
  ],
  declarations: []
})
export class ContexteModule {
  static initialiserContexte(paramEntree: InitialiserContexteEntree): Promise<ContexteService> {
    return lastValueFrom(contexteinstance.initialiserContexte(paramEntree));
  }
}