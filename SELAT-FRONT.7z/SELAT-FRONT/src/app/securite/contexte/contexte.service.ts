import { InjectionToken } from '@angular/core';

export const CONTEXTESERVICE = new InjectionToken<ContexteService>('Service du contexte');

export interface ContexteService {
  readonly UUID: string;
  readonly ENVIRONNEMENT: string;
  readonly VERSION: string;
  readonly OIDC_AUTORITE: string;
  readonly OIDC_CLIENT_ID: string;
  readonly OIDC_HOTE_REDIRECTION: string;
  readonly OIDC_SCOPE_API: string;
  readonly CHEMIN_API: string;
  RacineClient: string;
  NomUnique: string;
  IdUtil: string;
  NoSeqIndiv: string;
}
