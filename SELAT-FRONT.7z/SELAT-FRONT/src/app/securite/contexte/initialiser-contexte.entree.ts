export interface InitialiserContexteEntree {
  configuration: string;
  production: boolean;
}
