import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subscription } from 'rxjs';
import { map, mergeMap } from 'rxjs/operators';
import { v4 as UUID } from 'uuid';

import {
  StatutAuthentification,
  AuthentificationFacadeService,
  InitialiserAuthentificationEntree,
  Jeton
} from 'src/app/securite/authentification';
import { ContexteService } from './contexte.service';
import { InitialiserContexteEntree } from './initialiser-contexte.entree';

const CLEF_CACHE = 'parametres';

@Injectable()
export class ContexteImplService implements ContexteService {
  private contexteInitialise = false;
  readonly UUID = '';
  readonly ENVIRONNEMENT = '';
  readonly VERSION = '';
  readonly OIDC_AUTORITE = '';
  readonly OIDC_CLIENT_ID = '';
  readonly OIDC_HOTE_REDIRECTION = '';
  readonly OIDC_SCOPE_API = '';
  readonly CHEMIN_API = '';
  get NomUnique(): string { return this.Jeton?.unique_name ?? ''; }
  get RacineClient(): string { return this.OIDC_HOTE_REDIRECTION; }
  get NoSeqIndiv(): string { return atob(sessionStorage.getItem(CLEF_CACHE) ?? ''); }

  private idUtil = '';
  get IdUtil(): string {
    if (!this.idUtil) {
      this.idUtil = this.NomUnique.split('\\').pop() ?? '';
    }
    return this.idUtil;
  }

  private jeton: Jeton | undefined;
  get Jeton(): Jeton | undefined {
    if (!this.jeton) {
      this.jeton = this.authentification.recupererCopieJeton();
    }
    return this.jeton;
  }

  constructor(
    private http: HttpClient,
    private authentification: AuthentificationFacadeService
  ) {
    this.ecouterChangementEtatConnexion();
  }

  private ecouterChangementEtatConnexion(): Subscription {
    return this.authentification.ChangementEtat$.subscribe(etatConnexion => {
      if (this.jeton && etatConnexion !== StatutAuthentification.Authentifie) {
        this.jeton = undefined;
      }

      if (etatConnexion === StatutAuthentification.Deconnecte) {
        sessionStorage.removeItem(CLEF_CACHE);
      }
    });
  }

  initialiserContexte(paramEntree: InitialiserContexteEntree): Observable<ContexteService> {
    this.verifierInitialisationContexte();
    return this.http.get(paramEntree.configuration).pipe(
      map((resultat: object) => {
        Object.assign(this, { ...resultat, UUID: UUID() });
        const params = new URLSearchParams(window.location.search);
        const noSeqIndiv = params.get('noSeqIndiv');
        if (noSeqIndiv) {
          const info = btoa(noSeqIndiv);
          sessionStorage.setItem(CLEF_CACHE, info);
        }
        return this;
      }),
      mergeMap(resultat => {
        return this.initialiserServiceAuthentification(resultat).pipe(map(() => resultat));
      })
    );
  }

  private verifierInitialisationContexte(): void {
    if (this.contexteInitialise) {
      throw new Error(`Impossible d'initialiser plus d'une fois`);
    }
    this.contexteInitialise = true;
  }

  private initialiserServiceAuthentification(contexte: ContexteImplService): Observable<unknown> {
    const param: InitialiserAuthentificationEntree = {
      UrlSource: contexte.OIDC_AUTORITE,
      Oidc: {
        IdClient: contexte.OIDC_CLIENT_ID,
        UriHoteRedirection: contexte.OIDC_HOTE_REDIRECTION,
        ScopeAPI: contexte.OIDC_SCOPE_API
      }
    };

    return contexte.authentification.initialiserAuthentification(param);
  }
}
