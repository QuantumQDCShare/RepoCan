import { Component } from '@angular/core';

@Component({
  selector: 'app-banniere-haut',
  standalone: true,
  templateUrl: './banniere-haut.component.html',
  styleUrls: ['./banniere-haut.component.scss']
})
export class BanniereHautComponent { }
