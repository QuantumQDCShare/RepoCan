import { Component, Input } from '@angular/core';
import { FormGroup, ValidationErrors } from '@angular/forms';
import { FieldErrorsService } from '../../services/commun/field-errors.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-champ-erreur',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './champ-erreur.component.html',
  styleUrl: './champ-erreur.component.scss'
})
export class ChampErreurComponent {
  @Input() formGroup: FormGroup;
  @Input() fieldName: string;
  @Input() friendlyName: string;
  @Input() patternMessage: string;
  @Input() forceShowError: boolean;

  constructor(private service: FieldErrorsService) { }

  fieldErrors(field: string): ValidationErrors {
    const controlState = this.formGroup.controls[field];
    if (controlState == null) {
      return null;
    }

    return (this.service.ShowError(controlState, this.forceShowError) && controlState.errors) ? controlState.errors : null;
  }

  getErrorMessages(): string[] {
    const localFieldErrors = this.fieldErrors(this.fieldName);
    const errorMessages: string[] = [];
    if (!this.fieldErrors) {
      return errorMessages;
    }
    if (localFieldErrors?.required) {
      errorMessages.push(`${this.friendlyName} est obligatoire`);
    }
    if (localFieldErrors?.maxlength) {
      errorMessages.push(`${this.friendlyName} must not exceed ${localFieldErrors.maxlength.requiredLength}:requiredLength: characters`);
    }
    if (localFieldErrors?.minlength) {
      errorMessages.push(`${this.friendlyName}:${this.friendlyName} freindlyName: must be at least ${localFieldErrors.minlength.requiredLength}:requiredLength: characters`);
    }
    if (localFieldErrors?.min) {
      errorMessages.push(`${this.friendlyName}:${this.friendlyName} freindlyName: must be at least ${localFieldErrors.min.min}:min:`);
    }
    if (localFieldErrors?.email) {
      errorMessages.push(`${this.friendlyName} Should be an email address`);
    }
    if (localFieldErrors?.pattern) {
      errorMessages.push(this.patternMessage);
    }
    return errorMessages;
  }
}
