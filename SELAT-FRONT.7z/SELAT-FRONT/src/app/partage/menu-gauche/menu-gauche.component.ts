import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'app-menu-gauche',
  standalone: true,
  imports:[RouterLink],
  templateUrl: './menu-gauche.component.html',
  styleUrls: ['./menu-gauche.component.scss']
})
export class MenuGaucheComponent implements OnInit {
  menuElements: MenuItem[];
  ngOnInit(): void {
    this.menuElements = [
      {
        id: 'shc_piloter',
        label: 'Piloter',
        icon: 'nav-icon nav-icon_shipmments',
        items: [
          {
            id: 'message_explicatif',
            label: 'Messages explicatifs',
            icon: '',
            routerLink: ['/messagesexplicatifs']
          }
          ,
          {
            id: 'parametre_exploitation',
            label: "Parametres d'exploitations",
            icon: '',
            routerLink: []
          }
          ,
          {
            id: 'norme_gestion',
            label: 'Norme de gestion',
            icon: '',
            routerLink: ['/']
          }
          ,
          {
            id: 'organisme_provinciaux',
            label: 'Organisme provinciaux',
            icon: '',
            routerLink: ['/']
          },
          {
            id: 'test',
            label: 'Menu Test',
            icon: '',
            routerLink: ['/']
          }
        ]
      }
    ];
  }


 }
