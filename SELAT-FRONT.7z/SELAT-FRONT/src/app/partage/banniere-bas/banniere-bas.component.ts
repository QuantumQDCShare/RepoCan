import { Component } from '@angular/core';

@Component({
  selector: 'app-banniere-bas',
  standalone: true,
  templateUrl: './banniere-bas.component.html',
  styleUrls: ['./banniere-bas.component.scss']
})
export class BanniereBasComponent { }
