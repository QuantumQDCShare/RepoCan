export enum AppStates {
  PageErreurAuthentification = 'pageErreurAuthentification',
  PageErreurTechnique = 'pageErreurTechnique',
  PagePrincipal = 'AccueilComponent',
  PageIntrouvable = 'pageIntrouvable'
}
