﻿using Application.Employe.CreationEmploye;
using Application.ObjetDeTransfert;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;


namespace DDD.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class EmployeController : ControllerBase
    {
        private readonly ISender _mediateur;
        public EmployeController(ISender mediateur)
        {
            _mediateur = mediateur;
        }
 
        [HttpPost("CreerEmploye")]
        public async Task<ActionResult<bool>> CreerEmploye([FromBody] EmployeRequete nouvelEmploye)
        {
            // creation de la commande a envoyé
            var commande = new CreationEmployeCommand(nouvelEmploye);

            // envoi de la requete par le mediateur (mediatr)
            var resultat =await  _mediateur.Send(commande);

            if (resultat.IsFailure)
                return BadRequest(resultat.Error);

            return Ok(resultat.IsSuccess);
        }

    }
}
