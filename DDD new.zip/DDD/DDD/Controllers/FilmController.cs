﻿using Application.Employe.CreationEmploye;
using Application.ObjetDeTransfert;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Application.Film.AddFilm;


namespace DDD.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class FilmController : ControllerBase
    {
        private readonly ISender _mediateur;
        public FilmController(ISender mediateur)
        {
            _mediateur = mediateur;
        }

        [HttpPost("AddFilm")]
        public async Task<ActionResult<int>> AjouterFilm([FromBody] FilmRequest film)
        {
            // creation de la commande a envoyé
            var commande = new CreationFilmCommande(film);

            // envoi de la requete par le mediateur (mediatr)
            var resultat = await _mediateur.Send(commande);

            if (resultat.IsFailure)
                return BadRequest(resultat.Error);

            return Ok(resultat);
        }

    }
}
