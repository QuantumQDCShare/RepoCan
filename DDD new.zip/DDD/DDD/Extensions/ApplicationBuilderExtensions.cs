

using DDD.Intercepteur;

namespace DDD.Extensions;

public static class ApplicationBuilderExtensions
{
    public static void UtiliserExceptionIntercepteur(this IApplicationBuilder app)
    {
        app.UseMiddleware<ExceptionIntercepteur>();
    }
}