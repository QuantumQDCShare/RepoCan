﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domaine.Entites.Employe
{
    public record EmployeId(Guid Value)
    {
        public static EmployeId FromValue(Guid Value)
        {
            return new EmployeId(Value);
        }

        public static EmployeId New()
        {
            return FromValue(Guid.NewGuid());
        }
    }
}
