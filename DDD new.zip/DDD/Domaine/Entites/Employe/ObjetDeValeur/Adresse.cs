﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domaine.Entites.Employe.ObjetDeValeur
{
    public record Adresse(
        string Pays,
        string Etat,
        string Ville,
        string Rue);
    

    
}
