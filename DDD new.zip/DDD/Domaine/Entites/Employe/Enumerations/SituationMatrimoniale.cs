﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domaine.Entites.Employe.Enumerations
{
    public enum SituationMatrimoniale
    {
        Marie = 0,
        Celibataire = 1,
        Veuf = 2
    }
}
