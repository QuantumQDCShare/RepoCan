﻿

namespace Domaine.Entites.Employe;


public interface IEmployeRepository
{
    Task<Employe> RecuppereEmployeParID(Guid employeId);

    Task<IReadOnlyList<Employe>> ReccupereListeEmploye();

    Task<Guid> CreerEmploye(Employe employe);

    Task<bool> EmployeExiste(Guid employeId);
}
