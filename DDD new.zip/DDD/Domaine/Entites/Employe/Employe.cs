﻿using Domaine.Abstractions;
using Domaine.Entites.Employe.Enumerations;
using Domaine.Entites.Employe.ObjetDeValeur;
using System.Runtime.CompilerServices;


namespace Domaine.Entites.Employe
{
    public sealed class Employe : Entity<EmployeId>
    {
        // The private setter is used because we don't want to allow the property to be changed outside the scope of the entity
        public string? Nom { get; private set; }
        public string? Prenom { get; private set; }
        public DateTime? DateNaissance { get; private set; }

        public Adresse? Adresse { get; private set; }
        public SituationMatrimoniale? SituationMatrimoniale { get; private set; }

        public Employe(EmployeId Id, string nom, string prenom, DateTime date, Adresse adresse, SituationMatrimoniale situation) : base(Id)
        {
            Nom = nom;
            Prenom = prenom;
            DateNaissance = date;
            Adresse = adresse;
            SituationMatrimoniale = situation;
        }

        public static Employe Creer(EmployeId id, string nom, string prenom, DateTime date, Adresse adresse, SituationMatrimoniale situation)
        {
            return new Employe(id, nom, prenom, date, adresse, situation);
        }

    }
}
