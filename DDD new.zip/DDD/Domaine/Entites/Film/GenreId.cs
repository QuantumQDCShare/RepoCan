﻿

namespace Domaine.Entites.Film;

public record GenreId(int Value)
{
    public static GenreId FromValue(int Value)
    {
        return new GenreId(Value);
    }

}
