﻿

namespace Domaine.Entites.Film;


public interface IFilmRepository
{
     Task<Film> GetFilmById(int filmId);

     Task<IEnumerable<Film>> GetAllFilms();

     Task<int> AddFilm(Film film);

     Task<bool> UpdateFilm(Film employeId);
}
