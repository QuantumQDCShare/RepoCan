﻿using Domaine.Abstractions;

namespace Domaine.Entites.Film;

public sealed class Genre : Entity<GenreId>
{
    public string NomGenre { get; private set; }

    public Genre(GenreId Id, string nomGenre) : base(Id)
    {
        NomGenre = nomGenre;
    }

    public static Genre AddGenre(GenreId Id, string nomGenre)
    {
        return new Genre(Id, nomGenre);
    }
}
