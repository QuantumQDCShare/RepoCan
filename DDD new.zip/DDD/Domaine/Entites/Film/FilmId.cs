﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domaine.Entites.Film
{
    public record FilmId(int Value)
    {
        public static FilmId FromValue(int Value)
        {
            return new FilmId(Value);
        }

    }
}
