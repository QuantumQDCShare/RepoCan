﻿using Domaine.Abstractions;

namespace Domaine.Entites.Film;

public sealed class Film : Entity<FilmId>
{
    public string Titre { get; private set; }
    public string Realisateur { get; private set; }
    public decimal Budget { get; private set; }

    public string Synopsis { get; private set; }

    public bool BandeAnnonceDispo { get; private set; }

    public GenreId GenreId { get; private set; }

    public Film(FilmId id, string realisateur, string titre, decimal budget, string synopsis, bool bandDispo, GenreId genre) : base(id)
    {
        Id = id;
        Realisateur = realisateur;
        Titre = titre;
        Budget = budget;
        Synopsis = synopsis;
        BandeAnnonceDispo = bandDispo;
        GenreId = genre;
    }

    public static Film AddFilm(string realisateur, string titre, decimal budget, string synopsis, bool bandDispo, GenreId genreId)
    {
        return new Film(FilmId.FromValue(0), realisateur, titre, budget, synopsis, bandDispo, genreId);
    }
}
