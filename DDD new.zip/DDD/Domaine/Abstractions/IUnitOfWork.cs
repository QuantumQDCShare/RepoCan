﻿using Domaine.Entites.Employe;
using Domaine.Entites.Film;
using System.Data;



namespace Domaine.Abstractions
{
    public interface IUnitOfWork : IDisposable
    {
        IEmployeRepository EmployeRepository { get; }
        IFilmRepository FilmRepository { get; }

        void BeginTransaction();
        void Commit();

        void RollBack();
    }
}
