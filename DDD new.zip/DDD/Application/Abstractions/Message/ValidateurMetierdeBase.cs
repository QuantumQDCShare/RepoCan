﻿using Domaine.Abstractions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Abstractions.Message
{

    public class ErreurMetier
    {
        public List<Error> Erreurs { get; set; }
        public bool EstValide { get; set; }
    }
    public class ValidateurMetier<TCommand> where TCommand : ICommand
    {
          List<Error> listeErreurs = new List<Error>();
        public virtual async Task<ErreurMetier> VerifieAsync(TCommand commande)
        {

            listeErreurs = await ExecuteValidateurMetierAsync(commande);

            return new ErreurMetier() { Erreurs = listeErreurs, EstValide = !listeErreurs.Any() };
        }

        public virtual async Task<List<Error>> ExecuteValidateurMetierAsync(TCommand commande)
        {
            return listeErreurs;
        }
    }
}
