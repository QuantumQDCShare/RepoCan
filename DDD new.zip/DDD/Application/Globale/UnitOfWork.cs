﻿//using System.Data.SqlClient;
//using System.Data;
//using Domaine.Entites.Film;
//using Domaine.Entites.Employe;
//using Domaine.Abstractions;


//namespace Application.Globale;

//public class UnitOfWork : IUnitOfWork
//{
//    private IDbConnection _connection;
//    private IDbTransaction _transaction;
//    private IFilmRepository _filmRepository;
//    private IEmployeRepository _employeRepository;
//    private bool _disposed;

//    public UnitOfWork(string connectionString)
//    {
//        _connection = new SqlConnection(connectionString);
//        _connection.Open();
//        _transaction = _connection.BeginTransaction();
//    }

//    public IFilmRepository FilmRepository
//    {
//        get { return _filmRepository ?? (_filmRepository = new FilmRepository(_transaction)); }
//    }

//    public IEmployeRepository EmployeRepository
//    {
//        get { return _employeRepository ?? (_employeRepository = new EmployeRepository(_transaction)); }
//    }

//public void Commit()
//    {
//        try
//        {
//            _transaction.Commit();
//        }
//        catch
//        {
//            _transaction.Rollback();
//            throw;
//        }
//        finally
//        {
//            _transaction.Dispose();
//            _transaction = _connection.BeginTransaction();
//            resetRepositories();
//        }
//    }

//    private void resetRepositories()
//    {
//        _employeRepository = null;
//        _filmRepository = null;
//    }

//    public void Dispose()
//    {
//        dispose(true);
//        GC.SuppressFinalize(this);
//    }

//    private void dispose(bool disposing)
//    {
//        if (!_disposed)
//        {
//            if (disposing)
//            {
//                if (_transaction != null)
//                {
//                    _transaction.Dispose();
//                    _transaction = null;
//                }
//                if (_connection != null)
//                {
//                    _connection.Dispose();
//                    _connection = null;
//                }
//            }
//            _disposed = true;
//        }
//    }

//    public void RollBack()
//    {
//        throw new NotImplementedException();
//    }

//    ~UnitOfWork()
//    {
//        dispose(false);
//    }
//}
