﻿using Application.Abstractions.Message;
using Application.ObjetDeTransfert;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Film.AddFilm;

public sealed record CreationFilmCommande(FilmRequest FilmRequest) : ICommand;
