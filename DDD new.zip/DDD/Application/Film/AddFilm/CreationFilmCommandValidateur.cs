﻿using Application.Film.AddFilm;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Employe.CreationEmploye
{
    public class CreationFilmCommandeValidateur : AbstractValidator<CreationFilmCommande>
    {
        public CreationFilmCommandeValidateur()
        {
        //    RuleFor(c => c.FilmRequest.GenreId).NotEmpty().WithMessage("Le Genre est Obligatoire");
        //    RuleFor(c => c.FilmRequest.Titre).NotEmpty().WithMessage("Le Titre est Obligatoire");
        //    RuleFor(c => c.FilmRequest.Realisateur).NotEmpty().WithMessage("Le Realisateur est Obligatoire");
        }
    }
}
