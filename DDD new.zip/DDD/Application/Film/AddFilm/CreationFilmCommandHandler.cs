﻿using Domaine.Abstractions;
using Application.Abstractions.Message;
using Application.Film.AddFilm;
using Domaine.Entites.Film;



namespace Application.Employe.AddFilm
{
    public class CreationFilmCommandHandler : ValidateurMetier<CreationFilmCommande>, ICommandHandler<CreationFilmCommande>
    {
        private readonly IUnitOfWork _unitOfWork;


        public CreationFilmCommandHandler(IUnitOfWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        public async Task<Result> Handle(CreationFilmCommande request, CancellationToken cancellationToken)
        {
            var validateur = VerifieAsync(request);
            ErreurMetier result = validateur.Result;

            if (result.Erreurs.Any())
            {
               return Result.Failure(result.Erreurs.First());
            }

            try
            {
                var film = Domaine.Entites.Film.Film.AddFilm(request.FilmRequest.Realisateur, request.FilmRequest.Titre, request.FilmRequest.Budget,
            request.FilmRequest.Synopsis, request.FilmRequest.BandeAnnonceDispo, GenreId.FromValue(request.FilmRequest.GenreId));


                var resulat = await _unitOfWork.FilmRepository.AddFilm(film);

                //_unitOfWork.RollBack();
                _unitOfWork.Commit();

                return Result.Success(resulat);
            }
            catch (Exception ex)
            {

                _unitOfWork.RollBackAsync();
              return  Result.Failure(new Error(ex.Source, ex.Message));
               
            }


        }
    }
}
