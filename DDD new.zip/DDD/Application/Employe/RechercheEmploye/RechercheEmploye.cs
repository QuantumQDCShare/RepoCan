﻿using Application.Abstractions.Message;
using Application.ObjetDeTransfert.Reponses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Employe.RechercheEmploye
{
    public sealed record RechercheEmployeRequete(
       DateTime StartDate,
       DateTime EndDate) : IQuery<IReadOnlyList<EmployeReponse>>;
}
