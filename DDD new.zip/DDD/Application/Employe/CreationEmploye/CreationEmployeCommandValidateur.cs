﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Employe.CreationEmploye
{
    public class CreationEmployeCommandeValidateur : AbstractValidator<CreationEmployeCommand>
    {
        public CreationEmployeCommandeValidateur()
        {
            
            RuleFor(c => c.employeRequete.Nom).NotEmpty().WithMessage("Le nom est Obligatoire");
            RuleFor(c => c.employeRequete.Prenom).NotEmpty().WithMessage("Le Prenom est Obligatoire");
            RuleFor(c => c.employeRequete.Nom).MinimumLength(10).WithMessage("Le Nom doit etre min 10");


        }
    }
}
