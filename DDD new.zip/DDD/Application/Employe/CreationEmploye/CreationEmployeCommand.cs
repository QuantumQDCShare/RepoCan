﻿

using Application.Abstractions.Message;
using Application.ObjetDeTransfert;

namespace Application.Employe.CreationEmploye
{
    public sealed record CreationEmployeCommand(EmployeRequete employeRequete) : ICommand; 

    
}
