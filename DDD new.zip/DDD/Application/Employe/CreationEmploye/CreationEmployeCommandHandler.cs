﻿using Application.Abstractions.Message;
using Domaine.Abstractions;
using Domaine.Entites.Employe;
using Domaine.Entites.Employe.ObjetDeValeur;


namespace Application.Employe.CreationEmploye
{
    public class CreationFilmCommandHandler : ValidateurMetier<CreationEmployeCommand>, ICommandHandler<CreationEmployeCommand>
    {
        private readonly IEmployeRepository _repositoryEmploye;


        public CreationFilmCommandHandler(IEmployeRepository repositoryEmploye)
        {
            _repositoryEmploye = repositoryEmploye;
        }

        public async Task<Result> Handle(CreationEmployeCommand request, CancellationToken cancellationToken)
        {
            var validateur = VerifieAsync(request);

            Adresse adresse = new Adresse(request.employeRequete.Pays, request.employeRequete.Etat, request.employeRequete.Ville, request.employeRequete.Rue);

            var employe = Domaine.Entites.Employe.Employe.Creer(EmployeId.New(),
                request.employeRequete.Nom,
                request.employeRequete.Prenom,
                request.employeRequete.DateNaissance, adresse, request.employeRequete.SituationMatrimoniale);

           var resultat= _repositoryEmploye.CreerEmploye(employe);

            return Result.Success(resultat);
        }

        public override async Task<List<Error>> ExecuteValidateurMetierAsync(CreationEmployeCommand commande)
        {
            var liste = new List<Error>();
            if (!await _repositoryEmploye.EmployeExiste(commande.employeRequete.Id))
            {
                liste.Add(
                    new Error("Employe inexistant", "l'employe n'existe pas"));
            }
            return liste;
        }      
    }

}
