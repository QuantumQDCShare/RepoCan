
using Microsoft.Extensions.DependencyInjection;
using Application.Globale;
using FluentValidation;
using Domaine.Abstractions;
using System.Data.Common;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;

public static class InjectionDependanceApplication
{
    public static IServiceCollection InjecterApplication(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddMediatR(m =>
        {
            m.RegisterServicesFromAssembly(typeof(InjectionDependanceApplication).Assembly);


            //Order mathers
            m.AddOpenBehavior(typeof(LoggingBehavior<,>));
            m.AddOpenBehavior(typeof(ValidationBehavior<,>));
        });

        services.AddValidatorsFromAssembly(typeof(InjectionDependanceApplication).Assembly);

        return services;
    }
}