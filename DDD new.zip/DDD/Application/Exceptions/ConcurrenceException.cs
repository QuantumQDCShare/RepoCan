namespace Application.Exceptions;

public sealed class ConcurrenceException : Exception
{
    public ConcurrenceException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}