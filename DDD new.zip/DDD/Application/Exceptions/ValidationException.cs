namespace Application.Exceptions;

public class ValidationException : Exception
{
    public ValidationException(IEnumerable<ValidationErreurs> errors)
    {
        Errors = errors;
    }

    public IEnumerable<ValidationErreurs> Errors { get; set; }
}