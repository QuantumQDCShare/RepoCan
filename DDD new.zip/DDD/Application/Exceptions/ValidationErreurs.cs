namespace Application.Exceptions;

public sealed record ValidationErreurs(string propertyName, string errorMessage);