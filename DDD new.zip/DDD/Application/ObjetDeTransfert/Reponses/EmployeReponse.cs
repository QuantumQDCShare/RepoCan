﻿using Domaine.Entites.Employe.Enumerations;
using Domaine.Entites.Employe.ObjetDeValeur;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.ObjetDeTransfert.Reponses
{
    public sealed class EmployeReponse
    {
        public string Nom { get;  set; }
        public string Prenom { get;  set; }
        public DateTime DateNaissance { get;  set; }

        public Adresse Adresse { get;  set; }
        public SituationMatrimoniale SituationMatrimoniale { get;  set; }
    }
}
