﻿using Domaine.Entites.Employe.Enumerations;
using Domaine.Entites.Employe.ObjetDeValeur;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.ObjetDeTransfert
{
    public class EmployeRequete
    {
        public Guid Id { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public DateTime DateNaissance { get; set; }

        public string Pays { get; set; }
        public string Etat { get; set; }
        public string Ville { get; set; }
        public string Rue { get; set; }
        public SituationMatrimoniale SituationMatrimoniale { get;  set; }
    }
}
