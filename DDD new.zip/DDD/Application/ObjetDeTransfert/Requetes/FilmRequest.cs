﻿using Domaine.Entites.Employe.Enumerations;
using Domaine.Entites.Employe.ObjetDeValeur;
using Domaine.Entites.Film;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.ObjetDeTransfert
{
    public class FilmRequest
    {

        public string Titre { get; set; }
        public string Realisateur { get; set; }
        public decimal Budget { get; set; }

        public string Synopsis { get; set; }

        public bool BandeAnnonceDispo { get; set; }

        public int GenreId { get; set; }
    }
}
