USE [MovieDatabase]
GO
/****** Object:  StoredProcedure [dbo].[AddFilmProcedure]    Script Date: 13/02/2024 00:58:31 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER   PROCEDURE [dbo].[AddFilmProcedure] (
                                          @titre    nvarchar(200),
                                          @realisateur     nvarchar(200),
                                          @budget        DECIMAL(18, 0),
                                          @synopsis          nvarchar(500),
										  @BandeAnnonceDispo          bit=0,
                                          @GenreId integer)
AS
  BEGIN
            INSERT INTO Film
                        (
                         titre,
                         realisateur,
                         budget,
						 synopsis,
						 BandeAnnonceDispo,
						 GenreId)
                       
            VALUES     ( 
                         @titre,
                         @realisateur,
                         @budget,
                         @synopsis,
						 @BandeAnnonceDispo,
						 @GenreId)
       
  END
  
  
  
  
  
  
  USE [MovieDatabase]
GO
/****** Object:  StoredProcedure [dbo].[GetFilmIdProcedure]    Script Date: 13/02/2024 00:59:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER   PROC [dbo].[GetFilmIdProcedure]

(@Id INT)

AS

BEGIN

SET NOCOUNT ON

SELECT f.FilmId,f.Titre,f.Realisateur, f.Budget, g.NomGenre FROM 

Film f, Genre g
where g.GenreId=f.GenreId and f.FilmId=@Id


END





USE [MovieDatabase]
GO
/****** Object:  StoredProcedure [dbo].[GetGenreAllProcedure]    Script Date: 13/02/2024 01:00:05 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER   PROC [dbo].[GetGenreAllProcedure]


AS

BEGIN

SET NOCOUNT ON

SELECT g.GenreId, g.NomGenre FROM 

 Genre g


END




USE [MovieDatabase]
GO
/****** Object:  StoredProcedure [dbo].[UpdateFilmProcedure]    Script Date: 13/02/2024 01:00:17 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER   PROCEDURE [dbo].[UpdateFilmProcedure] (
                                          @titre    nvarchar(200),
                                          @realisateur     nvarchar(200),
                                          @budget        DECIMAL(18, 0),
                                          @synopsis          nvarchar(500),
										  @BandeAnnonceDispo          bit=0,
                                          @FilmId integer)
AS
  BEGIN
            Update Film set Titre=@titre,Realisateur=@realisateur,Budget=@budget, Synopsis=@synopsis, BandeAnnonceDispo=@BandeAnnonceDispo
			where FilmId=@FilmId
  END



