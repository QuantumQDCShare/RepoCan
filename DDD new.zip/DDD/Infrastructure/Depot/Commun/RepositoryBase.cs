﻿using Dapper;
using System;
using System.Data;

namespace Infrastructure.Depot.Commun
{

    //internal abstract class Repository<TEntity, TEntityId>
    //    where TEntity : Entity<TEntityId>
    //    where TEntityId : class
    //{
    //    private readonly IConfiguration _config;
    //    public Repository(IConfiguration config)
    //    {
    //        _config = config;
    //    }

    //    public async Task<IEnumerable<T>> LoadData<T, U>(string storedProcedure, U parameters, string ConnectionId = "Default")
    //    {
    //       using IDbConnection connection = new SqlConnection(_config.GetConnectionString(ConnectionId));

    //        return await connection.QueryAsync<T>(storedProcedure, parameters, commandType: CommandType.StoredProcedure);
    //    }

    //    public async Task SaveData<T>(string storedProcedure,T Parameters, string ConnectionId = "Default")
    //    {
    //        using IDbConnection connection = new SqlConnection(_config.GetConnectionString(ConnectionId));
    //        await connection.ExecuteAsync(storedProcedure, Parameters, commandType: CommandType.StoredProcedure);
    //    }
    //}

    internal abstract class RepositoryBase
    {

        private readonly IDbTransaction _transaction;
        private readonly IDbConnection _connection;

        protected RepositoryBase(IDbConnection connection)
        {
            _connection = connection;
            if (_connection != null && _connection.State == ConnectionState.Closed)
            {
                _connection.Open();
                _transaction = connection.BeginTransaction();
            }
            
        }

        public async Task<IEnumerable<T>> LoadData<T, U>(string storedProcedure, U parameters) =>
            await _connection.QueryAsync<T>(storedProcedure, parameters, _transaction, commandType: CommandType.StoredProcedure);

        public async Task<int> SaveData<T>(string storedProcedure, T Parameters)
        {
           return await _connection.ExecuteAsync(storedProcedure, Parameters, _transaction, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<T>> LoadDataSQL<T,U>(string sql,U parameters)
        {
           
            return await _connection.QueryAsync<T>(sql, parameters);
        }

        public async Task<int> ExecuteScalar<T,U>(string storedProcedure,  U Parameters)
        {
            return (int)await _connection.ExecuteScalarAsync(storedProcedure, Parameters, _transaction, commandType: CommandType.StoredProcedure);
        }




    }
}
