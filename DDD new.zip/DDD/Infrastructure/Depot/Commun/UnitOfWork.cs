﻿using System.Data.SqlClient;
using System.Data;
using Domaine.Entites.Film;
using Domaine.Entites.Employe;
using Domaine.Abstractions;
using Infrastructure.Depot;
using System.Data.Common;
using System.Transactions;
using System.Configuration;
using Microsoft.Extensions.Configuration;

namespace Infrastructure.Depot.Commun;

public class UnitOfWork : IUnitOfWork
{
    private IDbConnection _connection;
    private IDbTransaction _transaction;
    private IFilmRepository? _filmRepository;
    private IEmployeRepository? _employeRepository;
    private readonly IConfiguration _configuration;
    private bool _disposed;

#pragma warning disable CS8618 // Un champ non-nullable doit contenir une valeur non-null lors de la fermeture du constructeur. Envisagez de déclarer le champ comme nullable.
    public UnitOfWork(
#pragma warning restore CS8618 // Un champ non-nullable doit contenir une valeur non-null lors de la fermeture du constructeur. Envisagez de déclarer le champ comme nullable.
        IFilmRepository filmrepo,
        IEmployeRepository employeRepository,
        IConfiguration configuration,
        IDbConnection connection
        )
    {
        _filmRepository = filmrepo;
        _employeRepository = employeRepository;
        _configuration = configuration;
        _connection = connection;

        if (_connection != null && (_connection.State == ConnectionState.Closed || _connection.State == ConnectionState.Broken))
        {
            _connection.Open();
        }

    }



    public IFilmRepository FilmRepository
    {
        get { return _filmRepository ?? (_filmRepository = new FilmRepository(_connection)); }
    }

    public IEmployeRepository EmployeRepository
    {
        get { return _employeRepository ?? (_employeRepository = new EmployeRepository()); }
    }



    private void resetRepositories()
    {
        _employeRepository = null;
        _filmRepository = null;
    }

    public void Dispose()
    {
        dispose(true);
        GC.SuppressFinalize(this);
    }

    private void dispose(bool disposing)
    {
        if (!_disposed)
        {
            if (disposing)
            {
                if (_transaction != null)
                {
                    _transaction.Dispose();
                    _transaction = null;
                }
                if (_connection != null)
                {
                    _connection.Dispose();
                    _connection = null;
                }
            }
            _disposed = true;
        }
    }

 


    public void BeginTransaction()
    {
        _transaction=_connection.BeginTransaction();
       
    }


    public void Commit()
    {
        try
        {

            if (_transaction != null)
            {
                _transaction.Commit();
            }
        }
        catch
        {
            _transaction.Rollback();
            throw;
        }
        finally
        {
            _transaction.Dispose();
            _connection.Close();
            resetRepositories();
        }
    }


    public void RollBack()
    {
        _transaction.Rollback();
    }

    ~UnitOfWork()
    {
        dispose(false);
    }
}
