﻿using Domaine.Entites.Employe;
using Domaine.Entites.Film;
using Infrastructure.Depot.Commun;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Depot
{
    internal class FilmRepository : RepositoryBase, IFilmRepository
    {
        private readonly IDbConnection _connection;
        public FilmRepository(IDbConnection connection) :base(connection) 
        {
            _connection=connection;
        }

        public async Task<int> AddFilm(Film film)
        {
            
            var entier = await ExecuteScalar<Film,dynamic>("AddFilmProcedure", new
            {
                Titre = film.Titre,
                Realisateur = film.Realisateur,
                Budget = film.Budget,
                Synopsis = film.Synopsis,
                BandeAnnonceDispo = film.BandeAnnonceDispo,
                GenreId = film.GenreId.Value,
            });

            return entier;
        }


        public async Task<IEnumerable<Film>> GetAllFilms()
        {
            return await LoadData<Film, dynamic>("db.GetFilmAllProcedure", new { });
        }

        public async Task<Film> GetFilmById(int filmId)
        {
            IEnumerable<Film> resultat = await LoadData<Film, dynamic>("db.GetFilmIdProcedure", filmId);
            return resultat.FirstOrDefault();
        }

        public Task<bool> UpdateFilm(Film employeId)
        {
            throw new NotImplementedException();
        }

    }
}
