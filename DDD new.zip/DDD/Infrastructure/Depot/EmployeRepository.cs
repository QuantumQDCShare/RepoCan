﻿using Domaine.Entites.Employe;
using Infrastructure.Depot.Commun;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Infrastructure.Depot
{
    internal class EmployeRepository :  IEmployeRepository
    {
        public EmployeRepository() 
        {
        }

        public Task<Guid> CreerEmploye(Employe employe)
        {
            // Appel ADO .NET et reccuperation du Guid

            return Task.FromResult(Guid.NewGuid());
        }



        public Task<bool> EmployeExiste(Guid employeId)
        {
            return Task.FromResult(false);
        }

        public Task<IReadOnlyList<Employe>> ReccupereListeEmploye()
        {
            throw new NotImplementedException();
        }

        public Task<Employe> RecuppereEmployeParID(Guid employeId)
        {
            throw new NotImplementedException();
        }
    }
}
