

using Application.Globale;
using Domaine.Abstractions;
using Domaine.Entites.Employe;
using Domaine.Entites.Film;
using Infrastructure.Depot;
using Infrastructure.Depot.Commun;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.Data;
using System.Data.SqlClient;
namespace Infrastructure;

public static class InjectionDependanceInfrastructure
{
    public static IServiceCollection InjecterInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        AddUnitOfWork(services, configuration);
        AddDependencies(services, configuration);

        return services;
    }

    private static void AddDependencies(IServiceCollection services, IConfiguration configuration)
    {
        services.AddScoped<IEmployeRepository, EmployeRepository>();
        services.AddScoped<IFilmRepository, FilmRepository>();

    }

    private static void AddUnitOfWork(IServiceCollection services, IConfiguration configuration)
    {
        var connectionString = configuration.GetConnectionString("Database");

        services.AddScoped<IDbConnection>((sp) => new SqlConnection(connectionString));

        services.AddScoped<IUnitOfWork,  UnitOfWork >();

    }
}